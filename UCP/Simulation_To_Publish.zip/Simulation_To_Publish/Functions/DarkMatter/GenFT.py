#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""GenFT UCPv3 dark-matter halo model

This module implements a GenFT dark-matter halo using the band
template profile (MID-band–dominated eigenmode) and the scaling
relations:

    M(r; A, s)      = A s^3 M_0(r / s)
    rho(r; A, s)    = A       rho_0(r / s)
    Sigma(R; A, s)  = A s^2   Sigma_0(R / s)

where:
    - A is a dimensionless amplitude (mass scaling)
    - s is a radial scale (in kpc)
    - M_0, rho_0 are taken from genft_band_dm_halo_profile.csv

The interface mirrors Functions.DarkMatter.NFW:
    rho(p, R), M(p, R), g(p, R), Vrot(p, R)

Units:
    - Radii: kpc
    - rho:   Msun / kpc^3
    - M:     Msun
    - g:     (km/s)^2 / kpc
    - Vrot:  km/s
"""

##############################################################################
# Importing Modules
import os
import numpy as np
from scipy.interpolate import InterpolatedUnivariateSpline as ius
from Functions.DarkMatter import GenFT as DM
from Functions.DarkMatter import NFW
# My Modules
import Functions.Convert as cn
from Functions.Store import Store

##############################################################################
# Constants

# Gravitational constant in kpc (km/s)^2 / Msun
# (standard astro value)
G_KPC_KM2_S2_Msun = 4.30091e-6

##############################################################################
# Load the GenFT band template halo

_here = os.path.dirname(__file__)
_template_path = os.path.join(_here, "genft_band_dm_halo_profile.csv")

if not os.path.exists(_template_path):
    raise FileNotFoundError(
        "Could not find genft_band_dm_halo_profile.csv at:\n"
        f"    {_template_path}\n"
        "Please copy it from your genft_halo_package/DarkMatter directory."
    )

# Load base halo: this is the *template* (A=1, s=1) profile
_data = np.genfromtxt(_template_path, delimiter=",", names=True)

# Radius grid in kpc
_r0_kpc = _data["r_kpc"].astype(float)

# Total density and enclosed mass
# Treat these as the "M_0" and "rho_0" for scaling
_rho0_msun_kpc3 = _data["rho_total"].astype(float)
_M0_msun        = _data["M3D_total_Msun"].astype(float)

# Spline interpolants for the base profile
# We use k=3 (cubic) and allow slight extrapolation if needed
_rho0_spline = ius(_r0_kpc, _rho0_msun_kpc3, k=3)
_M0_spline   = ius(_r0_kpc, _M0_msun,        k=3)

##############################################################################
# Helper to pull A and s out of a lmfit Parameters object or dict


def _get_As(p):
    try:
        A = p["A"].value
    except Exception:
        A = p["A"]
    try:
        s = p["s"].value
    except Exception:
        s = p["s"]
    return float(A), float(s)


##############################################################################
# Public API: rho, M, g, Vrot


def rho(p, R):
    """GenFT UCPv3 dark-matter density profile.

    Parameters
    ----------
    p : lmfit.Parameters or dict-like
        Must contain:
            p["A"] : float
                Dimensionless amplitude (mass scaling).
            p["s"] : float
                Radial scale in kpc.
    R : scalar or array_like
        Galactocentric radius in kpc.

    Returns
    -------
    rho_DM : ndarray
        Dark-matter density at R, in Msun / kpc^3.
    """
    A, s = _get_As(p)
    R = np.asarray(R, dtype=float)
    x = R / s  # dimensionless radius in template units
    return A * _rho0_spline(x)


def M(p, R):
    """Enclosed GenFT dark-matter mass M(<R).

    Uses the scaling:
        M(r; A, s) = A s^3 M_0(r / s)

    Parameters
    ----------
    p : lmfit.Parameters or dict-like
        Contains 'A' and 's'.
    R : scalar or array_like
        Radius in kpc.

    Returns
    -------
    M_DM : ndarray
        Enclosed dark-matter mass in Msun.
    """
    A, s = _get_As(p)
    R = np.asarray(R, dtype=float)
    x = R / s
    return A * (s**3) * _M0_spline(x)


def g(p, R):
    """Spherical GenFT halo acceleration g(R).

    We define:
        g(R) = G M(<R) / R^2

    with G in kpc (km/s)^2 / Msun and R in kpc, so
        g has units of (km/s)^2 / kpc.

    Parameters
    ----------
    p : lmfit.Parameters or dict-like
    R : scalar or array_like
        Radius in kpc.

    Returns
    -------
    g_DM : ndarray
        Acceleration in (km/s)^2 / kpc.
    """
    R = np.asarray(R, dtype=float)
    R_kpc = np.maximum(R, 1e-6)  # avoid division by zero
    M_enc = M(p, R_kpc)
    return G_KPC_KM2_S2_Msun * M_enc / (R_kpc**2)


def Vrot(p, R):
    """GenFT spherical halo circular velocity V_c(R).

    Using:
        V_c^2(R) = G M(<R) / R

    with:
        - G in kpc (km/s)^2 / Msun
        - R in kpc
        - M in Msun
    """
    R = np.asarray(R, dtype=float)
    R_kpc = np.maximum(R, 1e-6)

    M_enc = M(p, R_kpc)
    v2 = G_KPC_KM2_S2_Msun * M_enc / R_kpc  # (km/s)^2

    # Guard against NaNs / negatives
    v2 = np.where(np.isfinite(v2) & (v2 > 0.0), v2, 0.0)

    return np.sqrt(v2)

