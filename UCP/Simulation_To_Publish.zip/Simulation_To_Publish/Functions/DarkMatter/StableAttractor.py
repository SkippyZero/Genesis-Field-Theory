# Functions/DarkMatter/StableAttractor.py

import numpy as np

# Density in Msun/pc^3 (same as Burkert)
RHO_UNITS = "Msun_pc3"


def rho(p, r_kpc):
    """
    Stable attractor-like profile:
        rho(r) = rho0 / (1 + (r/rc)^n)

    rho0 : central density [Msun/pc^3]
    rc   : core radius     [kpc]
    n    : slope exponent  (you fit this in p)
    """
    r = np.asarray(r_kpc, float)
    rho0 = p["rho0"].value     # Msun/pc^3
    rc   = p["rc"].value       # kpc
    n    = p["n"].value        # dimensionless

    return rho0 / (1.0 + (r/rc)**2)**n


def M(p, r_kpc, n_grid=400):
    """
    Enclosed mass M(<r) in Msun.

    r is in kpc; rho is Msun/pc^3, so we convert rho -> Msun/kpc^3
    via a factor 1e9 inside the integral.
    """
    r_arr = np.asarray(r_kpc, float)
    M_enc = np.zeros_like(r_arr)

    for i, Ri in enumerate(r_arr):
        if Ri <= 0:
            continue

        r_grid = np.linspace(0.0, Ri, n_grid)
        dr = r_grid[1] - r_grid[0]

        rho_pc3  = rho(p, r_grid)      # Msun/pc^3
        rho_kpc3 = rho_pc3 * 1.0e9     # Msun/kpc^3

        M_enc[i] = 4*np.pi*np.sum(rho_kpc3 * r_grid**2 * dr)

    return M_enc


def Vrot(p, r_kpc):
    """
    Circular velocity:
        V^2 = G M(<r) / r

    with:
        G in (kpc/Msun) * (km/s)^2  (you set this in fit_all_multiDM.py)
        r in kpc
        M in Msun
    so V comes out in km/s.
    """
    r = np.asarray(r_kpc, float)
    V = np.zeros_like(r)

    G = p["G"].value
    M_enc = M(p, r)

    mask = r > 0
    V[mask] = np.sqrt(G * M_enc[mask] / r[mask])

    return V
