#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""Dark Matter functions to produce dark matter density profile
"""

##############################################################################
# Importing Modules
import numpy as np
from scipy.interpolate import InterpolatedUnivariateSpline as ius

# My Modules
import Functions.Convert as cn

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
# __copyright__ = "Copyright 2007, The Cogent Project"
__credits__ = "Stacy McGaugh", "Frederico Lelli"
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code

def g(p, R, gobs, gbar):
    """Dark Matter acceleration

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - G : Gravitational constant
        - 4.302 [kpc km^2 / s^2 M⊙]
    - parameters in gobs and gbar

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius
        - [kpc]

    Returns:
    ---------------
    g: scalar / array
        - [km / s^2]
    """
    return gobs(p, R) - gbar(p, R)


def M(p, R, gobs, gbar):
    """Dark Matter mass as a function of radius
    Assumed spherically symmetric and Newtonian gravity

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - G : Gravitational constant
        * use correct units
    - parameters in gobs and gbar

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius [kpc]

    Returns:
    ---------------
    Mass: scalar / array
    """
    return (g(p, R, gobs, gbar) * (R * cn.kpc_to_km(R))) / (p["G"].value)


def rho(p, R, gobs, gbar):
    """Dark Matter density profile
    Assumed spherically symmetric and Newtonian gravity

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - G : Gravitational constant
        * use correct units
    - parameters in gobs and gbar

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius [kpc]

    Returns:
    ---------------
    rho: scalar / array
    """
    # arr = np.linspace(R[0], R[-1], len(R) * 10)
    f = ius(R, M(p, R, gobs, gbar), k=3)
    return -f.derivative()(R) / (4 * np.pi * np.square(cn.kpc_to_pc(R)))
