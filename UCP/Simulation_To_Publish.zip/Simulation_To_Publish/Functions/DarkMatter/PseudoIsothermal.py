#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Pseudo-isothermal dark-matter halo profile.

Profile:
    rho(r) = rho0 / (1 + (r / rc)^2)

Parameters (lmfit.Parameters)
---------------------------------
``rho0``
    Central density [Msun / pc^3].
``rc``
    Core radius [kpc].
``G``
    Gravitational constant in kpc km^2 / s^2 / Msun (fixed by callers).
"""
import numpy as np
from .. import Convert as cn

RHO_UNITS = "Msun_pc3"


def rho(p, R):
    R = np.asarray(R, dtype=float)
    rc = p["rc"].value
    rho0 = p["rho0"].value
    x = R / rc
    return rho0 / (1.0 + x**2)


def M(p, R):
    """Analytic enclosed mass for the pseudo-isothermal sphere."""
    R = np.asarray(R, dtype=float)
    rc = p["rc"].value
    rho0 = p["rho0"].value

    x = R / rc
    prefac = 4.0 * np.pi * rho0 * cn.kpc_to_pc(rc) ** 3
    return prefac * (x - np.arctan(x))


def g(p, R):
    R = np.asarray(R, dtype=float)
    R_safe = np.maximum(R, 1e-8)
    G = p["G"].value
    M_enc = M(p, R_safe)
    return G * M_enc / (R_safe * cn.kpc_to_km(R_safe))


def Vrot(p, R):
    R = np.asarray(R, dtype=float)
    return np.sqrt(g(p, R) * cn.kpc_to_km(R))