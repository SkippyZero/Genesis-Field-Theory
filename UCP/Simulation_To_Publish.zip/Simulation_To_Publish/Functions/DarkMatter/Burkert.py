# Functions/DarkMatter/Burkert.py

import numpy as np

# rho in Msun/pc^3
RHO_UNITS = "Msun_pc3"


def rho(p, r_kpc):
    """
    Burkert density profile:

        rho(r) = rho0 * r_c^3 / [ (r + r_c) (r^2 + r_c^2) ]

    rho0 = p["ps"]  (central density, Msun/pc^3)
    r_c  = p["rs"]  (core radius, kpc)
    """
    r_kpc = np.asarray(r_kpc, float)
    rho0  = p["ps"].value    # Msun/pc^3
    rc_k  = p["rs"].value    # kpc

    r_pc  = r_kpc * 1.0e3
    rc_pc = rc_k  * 1.0e3

    r_pc_safe = np.where(r_pc > 0.0, r_pc, 1e-6)

    num = rho0 * rc_pc**3
    den = (r_pc_safe + rc_pc) * (r_pc_safe**2 + rc_pc**2)

    return num / den  # Msun/pc^3


def M(p, r_kpc, n_grid=400):
    """Enclosed mass M(<r) in Msun."""
    r_arr = np.asarray(r_kpc, float)
    M_enc = np.zeros_like(r_arr)

    for i, Ri in enumerate(r_arr):
        if Ri <= 0:
            continue

        r_grid = np.linspace(0.0, Ri, n_grid)
        dr = r_grid[1] - r_grid[0]

        rho_pc3  = rho(p, r_grid)      # Msun/pc^3
        rho_kpc3 = rho_pc3 * 1.0e9     # Msun/kpc^3

        M_enc[i] = 4*np.pi*np.sum(rho_kpc3 * r_grid**2 * dr)

    return M_enc


def Vrot(p, r_kpc):
    """
    V^2 = G M(<r) / r, with:

    G in (kpc/Msun) * (km/s)^2,
    r in kpc,
    M in Msun.

    So V is in km/s.
    """
    r = np.asarray(r_kpc, float)
    V = np.zeros_like(r)

    G = p["G"].value
    M_enc = M(p, r)

    mask = r > 0
    V[mask] = np.sqrt(G * M_enc[mask] / r[mask])

    return V
