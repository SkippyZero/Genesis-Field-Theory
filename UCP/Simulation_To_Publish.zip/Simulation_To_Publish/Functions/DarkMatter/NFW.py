#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""Dark Matter functions to produce dark matter density profile
"""

##############################################################################
# Importing Modules
import numpy as np
# from scipy.interpolate import InterpolatedUnivariateSpline as ius

# My Modules
import Functions.Convert as cn

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
# __copyright__ = "Copyright 2007, The Cogent Project"
__credits__ = "Stacy McGaugh", "Frederico Lelli"
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code
RHO_UNITS = "Msun_pc3"


def rho(p, R):
    """Dark Matter density profile
    Paper 160505971v2.pdf eqn. 4

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - ps : scale density
        - [M⊙ / pc^3]
    - rs : scale radius
        - [kpc]

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius [kpc]

    Returns:
    ---------------
    rho: scalar / array
        - [M⊙ / pc^3]
    """

    return p["ps"].value / ((R / p["rs"].value) *
                            (1 + np.square(R / p["rs"].value)))


def M(p, R):
    """Dark Matter Mass(R)
    Paper 160505971v2.pdf eqn. 5

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - ps : scale density
        - [M⊙ / pc^3]
    - rs : scale radius
        - [kpc]

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius [kpc]

    Returns:
    ---------------
    Mass: scalar / array
    """
    v = p.valuesdict()
    return 4 * np.pi * np.power(cn.kpc_to_pc(v["rs"]), 3) * v["ps"] *\
        (np.log((R + v["rs"]) / v["rs"]) - (R / (R + v["rs"])))


def g(p, R):
    """Dark Matter spherical halo acceleration

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - ps : scale density
        - [M⊙ / pc^3]
    - rs : scale radius
        - [kpc]
    - G : Gravitational constant
        - 4.302 [kpc km^2 / s^2 M⊙]

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius
        - [kpc]

    Returns:
    ---------------
    g_DM: scalar / array
        - [km / s^2]
    """
    return p["G"].value * M(p, R) / (R * cn.kpc_to_km(R))


def Vrot(p, R):
    """Dark Matter spherical halo circular velocity

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - ps : scale density
        * use correct units
    - rs : scale radius
        * use correct units
    - G : Gravitational constant
        - 4.302 [kpc km^2 / s^2 M⊙]

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius
        - [kpc]

    Returns:
    ---------------
    V_DM: scalar / array
        - [km / s]
    """
    return np.sqrt(g(p, R) * cn.kpc_to_km(R))
