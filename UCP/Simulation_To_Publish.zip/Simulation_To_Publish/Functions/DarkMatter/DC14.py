#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""DC14 (Di Cintio+ 2014) double power-law dark-matter profile.

Profile:
    rho(r) = rho_s / ((r/r_s)^gamma * (1 + (r/r_s)^alpha)^{(beta - gamma)/alpha})

Parameters (lmfit.Parameters)
---------------------------------
``rho_s``
    Scale density [Msun / kpc^3].
``r_s``
    Scale radius [kpc].
``alpha``, ``beta``, ``gamma``
    Shape parameters controlling inner/outer slopes.
``G``
    Gravitational constant in kpc km^2 / s^2 / Msun.
"""
import numpy as np
from scipy.integrate import cumulative_trapezoid
from .. import Convert as cn

RHO_UNITS = "Msun_kpc3"


def rho(p, R):
    R = np.asarray(R, dtype=float)
    rho_s = p["rho_s"].value
    r_s = p["r_s"].value
    alpha = p["alpha"].value
    beta = p["beta"].value
    gamma = p["gamma"].value

    x = R / r_s
    return rho_s / (x ** gamma * (1.0 + x ** alpha) ** ((beta - gamma) / alpha))


def M(p, R):
    """Numerical enclosed mass for the DC14 profile."""
    R = np.asarray(R, dtype=float)
    R = np.atleast_1d(R)
    r_grid = np.logspace(-4, np.log10(max(np.max(R), 1e-3)), 400)
    rho_grid = rho(p, r_grid)
    integrand = rho_grid * 4.0 * np.pi * r_grid ** 2  # Msun/kpc^3 * kpc^2 = Msun/kpc
    M_grid = cumulative_trapezoid(integrand, r_grid, initial=0.0)
    return np.interp(R, r_grid, M_grid)


def g(p, R):
    R = np.asarray(R, dtype=float)
    R_safe = np.maximum(R, 1e-8)
    G = p["G"].value
    M_enc = M(p, R_safe)
    return G * M_enc / (R_safe * cn.kpc_to_km(R_safe))


def Vrot(p, R):
    R = np.asarray(R, dtype=float)
    return np.sqrt(g(p, R) * cn.kpc_to_km(R))