#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""LMFit functions
"""

##############################################################################
# Importing Modules

# import numpy as np
# import lmfit as lf  # Parameter module
# import itertools  # list iteration
# import pickle  # saving files (dill is better, but not included)
# import types
import copy as cp

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__license__ = "GPL"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
#                               Functions

def set(prop, params, setdict, inplace=False, full_output=False):
    """Sets params[name].value to values in varydict

    Info:
    ---------------
    designed for lmfit
    Sets params[name].value to values in varydict

    Parameters:
    ---------------
    params: lmfit parameter object

    Inputs:
    ---------------
    valuedict: dictionary
        dictionary of the .value setting of the parameters

    Returns:
    ---------------
    params: lmfit parameter object
    * orig: original value settings
    """
    if inplace is False:
        params = params.copy()

    if prop in ("value", "val"):
        prop = "user_value"

    orig = {}
    for key, val in setdict.items():  # iterating through valuesdict
        orig[key] = params[key].value
        params[key].__dict__[prop] = val  # setting .value to one in dict

    if full_output is True:
        return params, orig
    elif inplace is False:
        return params
    else:
        return


def set_true(params, varynames=None, inplace=False, full_output=False):
    """Sets params[name].vary=True to only the given names, all others=False

    Info:
    ---------------
    designed for lmfit
    Sets params[name].vary=True to only the given names

    Parameters:
    ---------------
    params: lmfit parameter object

    Inputs:
    ---------------
    names: string or tuple of strings
        the name of the parameters to set .vary states to True
        all other parameters .vary states are set to False

    Returns:
    ---------------
    params: lmfit parameter object
    orig: dictionary
        dictionary of the original .vary setting of all the parameters
        can be used with .set to reset original params .vary states
    """
    if inplace is False:
        params = params.copy()

    if varynames is None:
        varynames = []
    elif isinstance(varynames, str):
        varynames = [varynames]

    orig = {}  # making orig
    for name in params:  # iterating through params
        orig[name] = params[name].vary  # storing original .vary state
        params[name].vary = True if name in varynames else False

    if full_output is True:
        return params, orig
    elif inplace is False:
        return params
    else:
        return


def alternate(params, names, inplace=False, full_output=False):
    """switches params[name].vary state between True and False

    Info:
    ---------------
    designed for lmfit
    switches params[name].vary state between True and False

    Parameters:
    ---------------
    params: lmfit parameter object

    Inputs:
    ---------------
    names: string or tuple of strings
        the name of the parameters to switch .vary state

    Returns:
    ---------------
    params: lmfit parameter object
    """
    if inplace is False:
        params = params.copy()

    if isinstance(names, str):
        names = [names]

    # Alternating .vary
    orig = {}
    for name in names:
        orig[name] = params[name].vary
        params[name].vary = True if params[name].vary is False else False
        # bool((params[name].vary + 1) % 2)

    if full_output is True:
        return params, orig
    elif inplace is False:
        return params
    else:
        return
