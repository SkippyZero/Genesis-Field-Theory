#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""Observing a Baryonic Exponential Disk
"""

##############################################################################
# Importing Modules
import numpy as np
# import Functions.Observed.DiskMethods as bm

# My Modules
import Functions.Convert as cn

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
# __copyright__ = "Copyright 2007, The Cogent Project"
__credits__ = "Stacy McGaugh", "Frederico Lelli"
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code


def Vrot(p, R):
    """Atan observed rotation curve model
    From Courteau -- 9709201v2

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - V0 : "velocity center of rotation"
        - [km / s]
    - Vc : "an asymptotic velocity"
        - [km / s]
    - R0 : "spatial center of the galaxy"
        - [kpc]
    - Rt : "transition radius between the rising and flat part of the RC"
        - [kpc]

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius [kpc]

    Returns:
    ---------------
    Vrot: scalar / array
        - [km / s]
    """

    v = p.valuesdict()
    return v["V0"] + \
        2 * v["Vc"] * np.arctan2(R - v["R0"], v["Rt"]) / np.pi


def g(p, R):
    """Atan observed radial acceleration
    From Courteau -- 9709201v2

    Info:
    ---------------
    designed for lmfit

    Parameters:
    ---------------
    p: lmfit parameter object
    - V0 : "velocity center of rotation"
        - [km / s]
    - Vc : "an asymptotic velocity"
        - [km / s]
    - R0 : "spatial center of the galaxy"
        - [kpc]
    - Rt : "transition radius between the rising and flat part of the RC"
        - [kpc]

    Inputs:
    ---------------
    R: scalar / array
        Galactocentric radius [kpc]

    Returns:
    ---------------
    g: scalar / array
        - [km / s^2]
    """
    return Vrot(p, R)**2 / cn.kpc_to_km(R)
