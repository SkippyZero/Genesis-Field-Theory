#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""Plotting
"""

##############################################################################
# Importing Modules
import numpy as np
import matplotlib as plt

# My Modules
from main import *
from Plotting import errorfill

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
# __copyright__ = "Copyright 2007, The Cogent Project"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"

##############################################################################
# Begin Code


def SalmObservedPlot(ob, folder, params=None):
    """
    """
    params = Gal.params if params is None else params

    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(10, 4))

    for ID in Salm.IDs[Salm.ind]:

        # Vobs
        errorfill(Gal.fid.RCf.loc[ID, "R"],
                  Gal.fid.RCf.loc[ID, "Vobs"],
                  yerr=Gal.fid.RCf.loc[ID, "e_Vobs"],
                  ax=ax[0], label=ID)

        # gobs
        ax[1].loglog(Gal.fid.RCf.loc[ID, "R"],
                     ob.g(params, Gal.fid.RCf.loc[ID, "R"],
                          Gal.fid.RCf.loc[ID, "Vobs"], notfunc=True),
                     label=ID)

    # Plot Properties
    fig.suptitle("Observed Plots", position=(0.5, .975))
    ax[0].set_title("Vobs")
    ax[0].set_xlabel("R [kpc]")
    ax[0].set_ylabel(r"Vobs [$\frac{\mathrm{km}}{\mathrm{s}}$]")
    ax[0].legend(loc="best")

    ax[1].set_title(r"$\log_{10}(g_{\mathrm{obs}})$")
    ax[1].set_xlabel(r"$log_{10}\left(R \ \ [\mathrm{kpc}]\right)$")
    ax[1].set_ylabel(r"$\log_{10}\left(g_{\mathrm{obs}} \ \ [\frac{\mathrm{km}}{\mathrm{s}^2}]\right)$")
    ax[1].legend(loc="best")

    fig.tight_layout(rect=(0, -.025, 1, .975))
    fig.savefig("Output/images/" + folder + "/Observed")


def AllGalaxies(ob, folder):
    for prop, label, save in [("L[3.6]", "Lum ($10^9 L_{\odot}$)", "Lum"),
                              ("SBdisk_cent",
                               r"SB0 [$\frac{L_{\odot}}{pc^2}$]", "SB0"),
                              ("SBeff",
                               r"SBeff [$\frac{L_{\odot}}{pc^2}$]", "SBeff")]:
        print(prop, label)

        fig, ax = plt.subplots(nrows=2, ncols=2., figsize=(10, 8))

        # Plot Properties
        fig.suptitle("Observed Plots", position=(0.5, .975))
        ax[0, 0].set_title(r"$V_{obs}$")
        ax[0, 0].set_xlabel("R [kpc]")
        ax[0, 0].set_ylabel(r"$V_{obs}$ [$\frac{\mathrm{km}}{\mathrm{s}}$]")

        ax[1, 0].set_xlabel("R [kpc]")
        ax[1, 0].set_xscale("log")
        ax[1, 0].set_ylabel(r"$\log_{10}(V_{\mathrm{obs}} \ [\frac{\mathrm{km}}{\mathrm{s}}]$")
        ax[1, 0].set_yscale("log")

        ax[0, 1].set_title(r"$g_{\mathrm{obs}}$")
        ax[0, 1].set_xlabel(r"$R \ \ [\mathrm{kpc}]$")
        ax[0, 1].set_ylabel(r"$g_{\mathrm{obs}} \ \ [\frac{\mathrm{km}}{\mathrm{s}^2}]$")

        ax[1, 1].set_xlabel(r"$log_{10}\left(R \ \ [\mathrm{kpc}]\right)$")
        ax[1, 1].set_ylabel(r"$\log_{10}\left(g_{\mathrm{obs}} \ \ [\frac{\mathrm{km}}{\mathrm{s}^2}]\right)$")

        my_cmap = plt.cm.jet

        val = Gal.GSf.value[prop][Gal.ind_useIDs]

        sm = plt.cm.ScalarMappable(cmap=my_cmap, norm=plt.Normalize(vmin=val.min(), vmax=val.max()))
        sm.set_array(val)
        """Still need to normalize the mass by sm._A.max. SHouldn't have to.
        http://stackoverflow.com/questions/8342549/matplotlib-add-colorbar-to-a-sequence-of-line-plots"""

        for ID in Gal.useIDs:

            galx = Gal.galx[ID]

            color = my_cmap(galx[prop].value / sm._A.max())  # put on 0-1 scale
            alpha = (.8 * (galx[prop].value - sm._A.min()) /
                     (sm._A.max() - sm._A.min()) + .2)
            e_alpha = (.29 * (galx[prop].value - sm._A.min()) /
                       (sm._A.max() - sm._A.min()) + .01)


            # Vobs
            errorfill(galx.R.value, galx.Vobs.value,
                      yerr=galx.Vobs.error, ax=ax[0,0],
                      c=color, e_alpha=e_alpha, alpha=alpha)
            # ax[0].axhline(galx.Vflat, c=color, alpha=.1)

            errorfill(galx.R.value, galx.Vobs.value,
                      yerr=(0, 0), ax=ax[1,0],
                      c=color, e_alpha=.1, alpha=alpha)

            # gobs
            ax[0, 1].semilogy(galx.R.value,
                              ob.g(params, galx.R.value,
                                   galx.Vobs.value, notfunc=True),
                              c=color, alpha=alpha)

            ax[1, 1].loglog(galx.R.value,
                            ob.g(params, galx.R.value,
                                 galx.Vobs.value, notfunc=True),
                            c=color, alpha=alpha)

        cb1 = plt.colorbar(sm)
        cb1.set_label(label)

        fig.tight_layout(rect=(0, -.025, 1, .975))
        print("images/" + folder + "/All Observed " + save)
        fig.savefig("Output/images/" + folder + "/All Observed " + save)