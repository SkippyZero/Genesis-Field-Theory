#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""lmfit style store class. Code used from lmfit library.

LMFIT-py, scipy, and ASTEVAL Licenses provided below.

Copyright, Licensing, and Re-distribution
-----------------------------------------

The LMFIT-py code is distribution under the following license:

  Copyright (c) 2014 Matthew Newville, The University of Chicago
                     Till Stensitzki, Freie Universitat Berlin
                     Daniel B. Allen, Johns Hopkins University
                     Michal Rawlik, Eidgenossische Technische Hochschule, Zurich
                     Antonino Ingargiola, University of California, Los Angeles
                     A. R. J. Nelson, Australian Nuclear Science and Technology Organisation

  Permission to use and redistribute the source code or binary forms of this
  software and its documentation, with or without modification is hereby
  granted provided that the above notice of copyright, these terms of use,
  and the disclaimer of warranty below appear in the source code and
  documentation, and that none of the names of above institutions or
  authors appear in advertising or endorsement of works derived from this
  software without specific prior written permission from all parties.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THIS SOFTWARE.

-----------------------------------------
Some code sections have been taken from the scipy library whose licence is below.

Copyright (c) 2001, 2002 Enthought, Inc.
All rights reserved.

Copyright (c) 2003-2016 SciPy Developers.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

  a. Redistributions of source code must retain the above copyright notice,
     this list of conditions and the following disclaimer.
  b. Redistributions in binary form must reproduce the above copyright
     notice, this list of conditions and the following disclaimer in the
     documentation and/or other materials provided with the distribution.
  c. Neither the name of Enthought nor the names of the SciPy Developers
     may be used to endorse or promote products derived from this software
     without specific prior written permission.


THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY,
OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

-----------------------------------------
The ASTEVAL and astutils code is distribution under the following license:

  Copyright (c) 2016 Matthew Newville, The University of Chicago

  Permission to use and redistribute the source code or binary forms of this
  software and its documentation, with or without modification is hereby granted
  provided that the above notice of copyright, these terms of use, and the
  disclaimer of warranty below appear in the source code and documentation, and
  that none of the names of The University of Chicago or the authors appear in
  advertising or endorsement of works derived from this software without specific
  prior written permission from all parties.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
  THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
  DEALINGS IN THIS SOFTWARE.
"""

##############################################################################
# Importing Modules

import copy as cp
import numpy as np
import types as tp
import warnings
from matplotlib import pyplot as plt

try:
    from collections import OrderedDict
except ImportError:
    from ordereddict import OrderedDict

from numpy import array, sqrt  #, arcsin, cos, sin, inf, nan, isfinite

# import warnings
# warnings.filterwarnings("error")

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__license__ = "GPL"
__version__ = "2.0"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"

"""
The next version will drastically alter the way aka's are treated.
right now they are part of the OrderedDict part of Store and are filtered out
by all functions like .keys(), etc.
in future they will not be stored there but will be some getter / setter method
to access the master item / attribute
this is planning ahead for implementing an AST method so that aka can link two
items / attributes which are not in the same Store level
"""

##############################################################################
# ASTUTILS
# code modified from lmfit.astutils.py

import re

RESERVED_WORDS = ('and', 'as', 'assert', 'break', 'class', 'continue',
                  'def', 'del', 'elif', 'else', 'except', 'exec',
                  'finally', 'for', 'from', 'global', 'if', 'import',
                  'in', 'is', 'lambda', 'not', 'or', 'pass', 'print',
                  'raise', 'return', 'try', 'while', 'with', 'True',
                  'False', 'None', 'eval', 'execfile', '__import__',
                  '__package__')

RESERVED_ATTRS = ("name", "value", "aka", "_vars", "_attr_names")

# UNSAFE_ATTRS = ('__subclasses__', '__bases__', '__globals__', '__code__',
#                 '__closure__', '__func__', '__self__', '__module__',
#                 '__dict__', '__class__', '__call__', '__get__',
#                 '__getattribute__', '__subclasshook__', '__new__',
#                 '__init__', 'func_globals', 'func_code', 'func_closure',
#                 'im_class', 'im_func', 'im_self', 'gi_code', 'gi_frame',
#                 '__asteval__')

# NAME_MATCH = re.compile(r"[a-zA-Z_][a-zA-Z0-9_]*$").match


# def _open(filename, mode='r', buffering=0):
#     """read only version of open()"""
#     umode = 'rb' if mode == 'rb' else "r"
#     return open(filename, umode, buffering)


# LOCALFUNCS = {'open': _open}


def valid_symbol_name(name):
    """determines whether the input symbol name is a valid name

    This checks for reserved words, and that the name matches the
    regular expression ``[a-zA-Z_][a-zA-Z0-9_]``
    """
    if name in RESERVED_WORDS:
        return False
    elif name in RESERVED_ATTRS:
        return False

    return True


##############################################################################
# Store

class Store(OrderedDict):
    """Base class object modelled on lmfit Parameters class
    Store can be a container for many sub-objects or a single object
    It is a class system which is accessible like a dictionary

    __init__(name=None, value=None, **kw):
    Don't need to pass a name or value
    all kw are created with setattr

    Methods Created:
        .add(name, value=None, subparams=True, passkw=False, **kw)
        .add_many(*variables, passkw=True, **kw)
        .__getitemized__(key)
        .__setitemized__(key, value)
        .pretty_repr(oneline=False, pretty_print=False, subdir=True)
        ._link(name, link)
        ._akalink(name, aka=None)
        ._convert(name)
        .update(mydict=None, **kw)
        addto(self, inplace=True, **kw)
        transfer(self, obj, aka=None, **kw)
        add(self, name, value=None, has_sub=True, passkw=False,
            aka=None, link=None, **kw)
        add_many(self, *args, passkw=True, **kw)
        akakeys(self)
        valuesdict(self, only_vars=True)
        set_valuesdict(self, valuesdict, canaddnew=False)

    Methods Modified:
        .copy(deep=False, memo=None, _nil=[])
        .__copy__()
        .__deepcopy__(memo=None)
        .__getattr__(name)
        .__getitem__(key)
        .__setattribute__(key, value)
        .__setattr__(name, value)
        .__setitem__(key, value)
        .__delattr__(name)
        .__delitem__(key)
        .__array__()
        .__getstate__
        .__setstate__(state)
        keys(self, only_vars=True)
        values(self, only_vars=False)
        items(self, only_vars=False)
        .__call__(*args, *kw)
        append(self, other, inplace=True, full=False)

    .Value Math Methods:
        all methods use numpy functions where available
        __abs__, __neg__, __pos__, __nonzero__, __int__, __float__,
        __trunc__, __add__, __sub__, __div__, __truediv__, __floordiv__,
        __divmod__, __mod__, __mul__, __pow__, __gt__, __ge__, __le__,
        __lt__, __eq__, __ne__, __radd__, __rsub__, __rdiv__, __rtruediv__,
        __rdivmod__, __rfloordiv__, __rmod__, __rmul__, __rpow__
        power(exponent), square(), sqrt(), exp(), log(base=np.e)
    """

    def __init__(self, name=None, value=None, **kw):
        super(Store, self).__init__(self)

        object.__setattr__(self, "_attr_names", [])

        self.__setattribute__("name", name)
        self.__setattribute__("value", value)
        self.__setattribute__("aka", None)

        self.__setattribute__("_vars", [])

        # defaults to no subparams
        has_sub = True if kw.pop("has_sub", False) is True else False
        for key, val in kw.items():
            self.add(key, val, has_sub=has_sub)

    def copy(self, deep=False, memo=None, _nil=[]):
        """copy method

            Info:
            ---------------
            makes shallow or deep copy

            Arguments:
            ---------------
            deep: bool
                whether to make a deep or shallow copy
                default: False
            memo:
                memo for deepcopy
                default: None
            _nil:
                _nil for deepcopy
                default: []

            Returns:
            ---------------
            copy of self

            Exceptions:
            ---------------
            assert deep type bool
        """

        assert isinstance(deep, bool)

        if deep is True:
            return cp.deepcopy(self, memo, _nil)
        return cp.copy(self)

    def __copy__(self):
        """shallow copy method

            Info:
            ---------------
            Shallow copy via .copy(deep=False)

            Returns:
            ---------------
            copy: Store object
                shallow copy of self
        """
        return self.copy()

    def __deepcopy__(self, memo=None):
        """deep copy method

            Info:
            ---------------
            deep copy via .copy(deep=True)

            Returns:
            ---------------
            copy: Store object
                deep copy of self
        """
        return self.copy(deep=True, memo=memo)

    def __getitemized__(self, key):
        """OrderedDict __getitem__ method

            Arguments:
            ---------------
            key: str
                the key of item to get

            Returns:
            ---------------
            item
        """
        return OrderedDict.__getitem__(self, key)

    def __getattr__(self, name):
        """modified __getattr__ method

            Info:
            ---------------
            prioritizes attributes
            first tries __getattribute__ method
            then tries __getitemized__ method

            note python normally calls __getattribute__ first
            https://docs.python.org/3/reference/datamodel.html

            Arguments:
            ---------------
            name: str
                the name of attribute / item to get

            Returns:
            ---------------
            attribute or item, depending
        """
        try:
            return self.__getattribute__(name)
        except AttributeError:
            return self.__getitemized__(name)

    def __getitem__(self, key):
        """calls __getattr__
        """
        return self.__getattr__(key)

    def __setattribute__(self, name, value):
        """modified obj.__setattr__ method

            Info:
            ---------------
            modified __setattribute__ method
            name added to _attr_names if not already

            Arguments:
            ---------------
            name: str
                the name of attribute to set
            value:
                the value of the attribute
        """
        if name not in self._attr_names:
            self._attr_names.append(name)

        # do this with super?
        object.__setattr__(self, name, value)

    def __setitemized__(self, key, value):
        """modified OrderedDict.__setitem__ method

            Info:
            ---------------
            modified OrderedDict.__setitem__ method
            cannot add item if in RESERVED_ATTRS
            if Store object, add key to ._vars list

            Arguments:
            ---------------
            key: str
                the name of attribute to set
            value:
                the value of the item

            Exceptions:
            ---------------
            KeyError: key in RESERVED_ATTRS
                will not add key to ._vars list
                will not set item
        """
        if key in RESERVED_ATTRS:
            raise KeyError("'%s' is not a valid key" % key)

        if key not in self._vars and isStore(value):
            self._vars.append(key)

        OrderedDict.__setitem__(self, key, value)

    def __setattr__(self, key, value):
        """modified __setattr__ method

            Info:
            ---------------
            prioritizes attributes
            first tries __setattribute__ method
            then checks for valid_symbol_name
            then tries __setitemized__ method

            can only set attribute if it already exists
                (listed in _attr_names)
            new attributes can be made with __setattribute__

            Arguments:
            ---------------
            name: str
                the name of attribute / item to set
            value:
                the value of the attribute / item

            Exceptions:
            ---------------
            KeyError: key not valid_symbol_name
                happens if making item, not attr, and is not valid symbol name
                will not set item
            KeyError: key in RESERVED_ATTRS
                happens in __setitemized__
                will not add key to ._vars list
                will not set item
        """
        if key in self._attr_names:
            self.__setattribute__(key, value)

        elif not valid_symbol_name(key):
            raise KeyError("'%s' is not a valid key" % key)

        else:
            self.__setitemized__(key, value)

    def __setitem__(self, key, value):
        """calls __setattr__
        """
        self.__setattr__(key, value)

    def __delattr__(self, name):
        """modified __delattr__ method

            Info:
            ---------------
            prioritizes attributes
                cannot delete attributes in RESERVED_ATTRS
                    will set to None and print warning
            deleting Store item also removes from ._vars list

            Arguments:
            ---------------
            name: str
                the name of attribute / item to delete

            Exceptions:
            ---------------
            KeyError: name not in self
                happens if deleting item (not in RESERVED_ATTRS or _attr_names)
                will not delete item
            Warning: name in RESERVED_ATTRS
                cannot delete attributes in RESERVED_ATTRS, will set to None
        """
        if name in RESERVED_ATTRS:
            warnings.warn("'%s' cannot be deleted. Setting to None" % name)
            self.__setattribute__(name, None)

        elif name in self._attr_names:
            object.__delattr__(self, name)

        elif name not in self:
            raise KeyError("'%s' DNE" % name)

        else:
            if isStore(self[name]):
                self._vars.pop(name)
            OrderedDict.__delitem__(self, name)

    def __delitem__(self, key):
        """calls __delattr__"""
        self.__delattr__(key)

    def __array__(self):
        """
        self.values to array
        """
        return array([v for v in self.values()], dtype=object)

    def __reduce__(self):
        """
        Required to pickle Store.
        """
        return self.__class__, (), self.__getstate__()

    def __getstate__(self):
        """__getstate__
        returns attrs and items using {__dict__, items()}
        """
        out = OrderedDict()
        out["attrs"] = self.__dict__
        out["items"] = OrderedDict((p for p in OrderedDict.items(self)
                                   if p[0] not in self.akakeys()))
        return out

    def __setstate__(self, state):
        """__setstate__
        state is of form {attrs: __dict__, items: odict}
        """

        object.__setattr__(self, "_attr_names",
                           state["attrs"]["_attr_names"])

        # assign attribute values
        for name in self._attr_names:
            self[name] = state["attrs"][name]

        # assign item values
        for name, val in state["items"].items():
            self[name] = val

            if isStore(val):
                self._akalink(name, val.aka)

    def pretty_repr(self, oneline=False, pretty_print=False,
                    subdir=True):
        if oneline:
            s = "'%s': " % (self.__class__.__name__)
            for key in [s for s in self._attr_names if s[0] != "_"]:
                s += "%s: %s, " % (key, self[key])
            s += "  ({"
            s += super(Store, self).__repr__()
            s += "    })"
            return s

        s = "\n'%s': %s\n" % (self.__class__.__name__, self.name)
        for key in [s for s in self._attr_names if s[0] != "_"]:
            s += "\t'%s': %s, \n" % (key, self[key])
        s += "  ({\n"
        for key in self.keys():
            if isStore(self[key]):
                s += "\t'%s': %s, \n" % (key,
                                         self[key].pretty_repr(oneline=True))
            else:
                s += "\t'%s': %s, \n" % (key, self[key])

        s += "    })\n"
        if pretty_print is True:
            print(s)
        return s

    def __str__(self):
        return self.pretty_repr()

    # @property
    def pretty_print(self):
        """
        """
        self.pretty_repr(pretty_print=True)

    def _link(self, name, link):
        assert isinstance(link, str), "link is not str"

        self[name] = self[link]

        if isStore(self[name]):
            self._vars.pop(self._vars.index(name))

    def _akalink(self, name, aka=None):
        if aka not in (None, False):  # other names for parameter
            if isinstance(aka, str):  # single string
                self._link(aka, name)
            else:  # list of aka
                for ref in aka:
                    self._link(ref, name)

    def _convert(self, name):
        """converts self[name] to Store
        """
        assert isinstance(name, str)
        assert not ismytype(self[name]), "already Store"

        value = self[name]
        self.__delattr__(name)

        self[name] = Store(name, value)

    def update(self, mydict=None, **kw):
        """
        mydict may be ordered dictionary and order is preserved
        kw is unordered dictionary

        """
        mydict = {} if mydict is None else mydict

        for key, val in mydict.items():
            self[key] = val

        for key, val in kw.items():
            self[key] = val

    def addto(self, inplace=True, **kw):
        """add items to this Store object

            Arguments:
            ---------------
            inplace: bool
                whether to add in place or return modified object

            Key-Word Arguments:
            -------------------
            any kwargs will be created as items of Store object

            Returns:
            ---------------
            if inplace is False:
                modified Store object
        """
        if inplace is True:
            self.update(kw)
        else:
            out = self.__copy__()
            out.update(kw)
            return out

    def transfer(self, obj, aka=None):
        """transfer Store object into this Store object as an item

            Info:
            ---------------
            transfer Store objecft into this Store object as an item

            Arguments:
            ---------------
            obj: Store object
                Store object to be transfer
            aka: str, None
                the aka for the Store object

        """

        self.__setattr__(obj.name, obj)
        self._akalink(obj.name, aka)
        self[obj.name].aka = aka

    def add(self, name, value=None, aka=None, link=None,
            has_sub=True, passkw=True, **kw):
        """add attribute to object

            Info:
            ---------------
            adds an attribute to the object
            can be a normal attribute or Store object

            Arguments:
            ---------------
            name: str
                the name of the object
            value: anything
                the value of the object
                * default: None
            has_sub: bool
                whether the kwargs are instantiated as myobject objects
                * default: True
            passkw: bool
                whether subparams are passed the remaining kw
                * default: False
            aka: str, None
                alias for added attribute. Can be accessed instead of main name
                ex: tmp = myobject("temp", "this is a container")
                    tmp.add("subparam", value=5, aka="sp")
                    tmp["sp"] == tmp["subparam"] = tmp.subparam == tmp.sp
                * default: None
            link: str, None
                link for accessing another attribute.
                    Equivalent to aka but for existing items
                if link is not None, *only* a link and akas will be created

            Key-Word Arguments:
            -------------------
            any kwargs will be created as items of Store object
        """

        # Link a Store
        if link is not None:  # Link to a previously created parameter
            assert link in self, "link does not exist"
            self._link(name, link)

        # Make a Store
        else:
            if has_sub is True:  # own container
                if passkw is True:  # subparam gets remaining kws
                    self.__setitemized__(name, Store(name, value, **kw))
                else:  # subparam only name, value
                    self.__setitemized__(name, Store(name, value))
            else:  # just OrderedDict item in self
                self.__setitemized__(name, value)

        # aka
        self._akalink(name, aka)
        if has_sub is True:
            self.__getitemized__(name).aka = aka

    def add_many(self, *args, passkw=True, **kw):
        """add attribute to object

            if passkw is True:
                the kw will be passed to all the variables.
                Any included dictionaries will be passed and supercede the kw

            Info:
            ---------------
            adds attribute(s) to the Store object
            attributes are stored in an ordered dictionary

            Arguments:
            ---------------
            variables: list of (list of) attributes
                ex: "name1", ("name2"), ("name3", {subparam dict}),
                    ("name4", value4), ("name5", value5, {subparam dict})
            passkw: bool
                whether subparams are passed to the remaining kw
                * default: True

            Key-Word Arguments:
            -------------------
            # aka: str
            #     alias for added attribute. Can be accessed instead of main name
            #     ex: tmp = Store("temp", "this is a container")
            #         tmp.add("subparam", value=5, aka="sp")
            #         tmp["sp"] == tmp["subparam"] = tmp.subparam == tmp.sp
            #     * default: False
            **kw: anything
                any kwargs will be created as items of Store
        """

        if passkw is True:
            kwpass = kw
        else:
            kwpass = {}

        for var in args:
            assert len(var) > 0,\
                "variable {} not right type (list or str)".format(var)

            # only name
            if isinstance(var, str):
                self.add(var, **kwpass)

            # only named, but packaged
            elif len(var) == 1:
                self.add(*var, **kwpass)

            # name and value
            elif len(var) == 2:
                self.add(*var)

            # name, value, & dict
            elif len(var) == 3:
                # combining dictionaries.
                passdict = {**kwpass, **var[2]}
                passdict["passkw"] = True
                self.add(var[0], var[1], **passdict)

    def akakeys(self):
        """array of aka keys

            Info:
            ---------------
            array of aka keys

            Returns:
            ---------------
            keys: list
                array of aka keys
        """
        return [key for key, val in OrderedDict.items(self)
                if isStore(val) and key not in self._vars]

    def keys(self, only_vars=False):
        """array of keys

            Info:
            ---------------
            array of keys

            Returns:
            ---------------
            keys: array
                array of keys
        """

        if only_vars is True:
            return self._vars
        return [key for key in OrderedDict.keys(self)
                if key not in self.akakeys()]

    def values(self, only_vars=False):
        """values of items in self

            Info:
            ---------------
            values of items in self

            Arguments:
            ---------------
            only_vars: bool
                whether to include non-Store objects
                default: False

            Returns:
            ---------------
            values: odict_items (ordered dictionary)
                array of values
        """
        if only_vars is False:
            return [val for key, val in OrderedDict.items(self)
                    if key not in self.akakeys()]
        return [self[key] for key in self._vars]

    def items(self, only_vars=False):
        """dictionary of keys, values

            Info:
            ---------------
            dictionary of key, values in items
            if only Store objects are selected, the .value is returned
                rather than the whole object

            Arguments:
            ---------------
            only_vars: bool
                whether to include non-Store objects
                default: False

            Returns:
            ---------------
            items: odict_items (ordered dictionary)
                dictionary of keys, values
        """
        if only_vars is False:
            return [(key, val) for key, val in OrderedDict.items(self)
                    if key not in self.akakeys()]
        return [(p.name, p.value) for p in self.values(only_vars)]
        # return OrderedDict(((p.name, p.value) for p in self.values(only_vars))
        #                    ).items()

    def iter(self):
        """iterable

            Info:
            ---------------
            generator form of .values(only_vars=True)

            Returns:
            ---------------
            objects for iteration
        """
        return (self[key] for key in self._vars)

    def valuesdict(self):
        """dictionary of keys, values

            Info:
            ---------------
            dictionary of values of Store objects in items

            Returns:
            ---------------
            valuesdict: odict_items (ordered dictionary)
                dictionary of values
        """
        # return self.items(only_vars=True)
        return OrderedDict(((self[v].name, self[v].value) for v in self._vars)
                           ).items()

    def set_valuesdict(self, valuesdict, canaddnew=False):
        """Sets attribute values to match those in valuesdict

            Info:
            ---------------
            Sets attribute values to match those in valuesdict
            can be used to create new items in .vars{}
                Dangerous. doesn't play well with others

            Arguments:
            ---------------
            valuesdict: dictionary of values
            addnew: Bool

            Returns:
            ---------------
            .value(*args, **kw)
        """
        assert isinstance(valuesdict, dict), "valuesdict not dict type"
        assert isinstance(addnew, bool), "addnew not bool type"

        if canaddnew is True:
            for key, val in valuesdict.items():
                if key in self:
                    self[key].value = val
                else:
                    self[key] = Store(key, val)
        else:
            for key, val in valuesdict.items():
                if key in self:
                    self[key].value = val

    # .value Methods
    ######################

    def __call__(self, *args, **kw):
        """modified call method

            Info:
            ---------------
            tries to call .value with the passed args & kwargs

            Arguments:
            ---------------
            *args: arguments for call
            **kw: kwargs for call

            Returns:
            ---------------
            .value(*args, **kw)
        """
        return self.value(*args, **kw)

    def append(self, other, inplace=True, full_out=False):
        """append to self.value

        Info:
        ---------------
        append to self.value

        Arguments:
        ---------------
        other: what is being appended
        inplace: append in place

        Returns:
        ---------------
        None if full_out False (default)
        .value if full_out True

        Exceptions:
        ---------------
        AttributeError: if cannot append
        """
        if inplace:
            self.value.append(other)
            if full_out:
                return self.value
        elif full_out:
            out = cp.copy(self.value)
            return out.append(other)

    # .Value Math Methods
    ######################
    def __abs__(self):
        """abs"""
        return abs(self.value)

    def __neg__(self):
        """neg"""
        return -self.value

    def __pos__(self):
        """positive"""
        return +self.value

    def __nonzero__(self):
        """not zero"""
        return self.value != 0

    def __int__(self):
        """int"""
        return int(self.value)

    def __float__(self):
        """float"""
        return float(self.value)

    def __trunc__(self):
        """trunc"""
        return self.value.__trunc__()

    def __add__(self, other):
        """+"""
        try:
            return np.add(self.value, other)
        except TypeError:
            return self.__radd__(other)

    def __sub__(self, other):
        """-"""
        try:
            return np.subtract(self.value, other)
        except TypeError:
            return -self.__rsub__(other)

    def __div__(self, other):
        """/"""
        try:
            return np.divide(self.value, other)
        except TypeError:
            return np.divide(1., self.__rdiv__(other))
    __truediv__ = __div__

    def __floordiv__(self, other):
        """//"""
        return np.floor_divide(self.value, other)

    def __divmod__(self, other):
        """divmod"""
        return np.divmod(self.value, other)

    def __mod__(self, other):
        """%"""
        return np.mod(self.value, other)

    def __mul__(self, other):
        try:
            return np.multiply(self.value, other)
        except TypeError:
            return self.__rmul__(other)

    def __pow__(self, other):
        """**"""
        return np.power(self.value, exponent)

    def power(self, exponent):
        """**"""
        return np.power(self.value, exponent)

    def square(self):
        """**2"""
        return np.square(self.value)

    def sqrt(self):
        """sqrt()"""
        return np.sqrt(self.value)

    def exp(self):
        """exp()"""
        return np.exp(self.value)

    def log(self, base=np.e):
        """log_{base}()"""
        return np.divide(np.log(self.value),
                         np.log(base))

    def __gt__(self, other):
        """>"""
        return self.value > other

    def __ge__(self, other):
        """>="""
        return self.value >= other

    def __le__(self, other):
        """<="""
        return self.value <= other

    def __lt__(self, other):
        """<"""
        return self.value < other

    def __eq__(self, other):
        """=="""
        return self.value == other

    def __ne__(self, other):
        """!="""
        return self.value != other

    def __radd__(self, other):
        """+"""
        return np.add(other, self.value)

    def __rsub__(self, other):
        """-"""
        return np.subtract(other, self.value)

    def __rdiv__(self, other):
        return np.divide(other, self.value)
    __rtruediv__ = __rdiv__

    def __rdivmod__(self, other):
        """divmod (right)"""
        return np.divmod(other, self.value)

    def __rfloordiv__(self, other):
        """// (right)"""
        return np.floor_divide(other, self.value)

    def __rmod__(self, other):
        """% (right)"""
        return np.mod(other, self.value)

    def __rmul__(self, other):
        return np.multiply(other, self.value)

    def __rpow__(self, other):
        """** (right)"""
        return np.power(other, self.value)


def isStore(x):
        """Test type is Store"""
        return (isinstance(x, Store) or
                x.__class__.__name__ == 'Store')


# test = Store("Test Store", "value")
# test["t"] = 2
# od = OrderedDict((("x", 33), ("y", 44), ("z", 55)), aa=22, ab=11)
# test.update(od, ba=4)

# test.add("thing2", 21, aka="myaka")
# test.add("thing3", 22, aka="myaka2")
# # print(test["myaka"].name)

# test.add("Preliminary", aka="prlm",
#          RCf=None, RC=None, GSf=None, GS=None,
#          params="test")

# print(test)
# print(test["prlm"])

# # print(test.__getstate__()["items"]["thing2"])

# # print(test.__dict__)

# import pickle
# with open("test" + ".pickle", 'wb') as output_file:
#           pickle.dump(test, output_file)

# del test, od

# with open("test" + ".pickle", "rb") as input_file:
#         test = pickle.load(input_file)

# print(test)
# print(test["prlm"])
