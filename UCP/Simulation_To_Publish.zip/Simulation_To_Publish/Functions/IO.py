# -*- coding: utf-8 -*-
# All the Functions

##############################################################################
# Importing Modules
import pickle  # saving files (dill is better, but not included)

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__license__ = "GPL"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Functions

def to_pickle(obj, filename, protocol=0, print_status=False, ext=""):
    """Save object with pickle

    Info:
    ---------------
    saves with pickle.HIGHEST_PROTOCOL

    Arguments:
    ---------------
    obj: object
        obj to save
    filename: string
        file path for saving obj
    protocol: int
        pickle.dump protocol
    print_status: bool
        True: prints if saved
    ext: str
        the file extension
        do not prepend "." in extension
        default: "" (doesn't add to filename)

    Returns:
    ---------------
    None, saves file
    """
    if len(ext) > 0:
        ext = "." + ext

    with open(filename + ext, 'wb') as output_file:
        pickle.dump(obj, output_file, protocol=protocol)

    if print_status is True:
        print(filename, "succesfully saved")


def save_df(df, fpath, save_pickle=False,
            print_status=False, ext="pickle"):
    """Save dataframe

    Info:
    ---------------
    can save .pickle, .csv, .html

    Arguments:
    ---------------
    obj: object
        obj to save
    fpath: string
        file path for saving obj
    save_pickle: bool
            whether to save dataframes as .pickle files
            default: False
    protocol: int
        pickle.dump protocol
    print_status: bool
        True: prints if saved
    ext: str
        the file extension
        do not prepend "." in extension
        default: "pickle" ("" does nothing)

    Returns:
    ---------------
    None, saves file
    """
    if len(ext) > 0:
        ext = "." + ext

    if save_pickle is True:
        df.to_pickle(fpath + ext)

    df.to_csv(fpath + ".csv")
    df.to_html(fpath + ".html")

    if print_status is True:
        print(fpath, " saved")


def from_pickle(filename, print_status=False, ext=""):
    """open object with pickle

    Info:
    ---------------
    loads object with pickle

    Input:
    ---------------
    filename: string
        file path for saving obj
    print_status: boolean
        True: prints if opened
        False: nothing
    ext: str
        the file extension
        do not prepend "." in extension
        default: "" (doesn't add to filename)
    """
    if len(ext) > 0:
        ext = "." + ext

    with open(filename + ext, "rb") as input_file:
        file = pickle.load(input_file)

    if print_status is True:
        print(filename, "succesfully opened")

    return file
