#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""Fitters
"""

##############################################################################
# Importing Modules

# My Modules
#from Functions.Store import store

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
# __copyright__ = "Copyright 2007, The Cogent Project"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code

def residual(p, func, fargs, measured, error=None, **kw):
    """residual function

    Info:
    ---------------
    standard residual function.
    |measured - model| / error

    Parameters:
    ---------------
    p: generally lmfit parameter object
       but works as any array which func accepts

    Arguments:
    ---------------
    func : function
        func(params, *args)
        the function for the model
        must return a scalar / ndarray
    fargs : list
        the non-parameter inputs to func
        * must be a list since it is unpacked
    measured : scalar / ndarray
        the measured quantity
    error : scalar / ndarray
        the y-error in the measurement

    Key-Word Arguments:
    -------------------
    None

    Returns:
    ---------------
    residual: scalar / array
    """
    if fargs is None:
        fargs = []
    if error is None:
        return (measured - func(p, *fargs))
    return (measured - func(p, *fargs)) / error


def wgt_residual(p, func, fargs, measured, error=None,
                 wgt_func=None, wgt_args=None, **kw):
    """weighted residual function

    Info:
    ---------------
    weighted residual function.
    |measured - model| / error

    Parameters:
    ---------------
    p: generally lmfit parameter object
       but works as any array which func accepts

    Arguments:
    ---------------
    func : function
        func(params, *args)
        the function for the model
        must return a scalar / ndarray
    fargs : list
        the non-parameter inputs to func (& wgt_func)
        * must be a list since it is unpacked
    measured : scalar / ndarray
        the measured quantity
    error : scalar / ndarray
        the y-error in the measurement
        * optional: default is None
            then the residual is not divided by the error
    wgt_func : function
        wgt_func(params, *args)
        the function for the weighting
        must return a scalar / ndarray
        * optional: default is None
            then the residual is unweighted
    wgt_args : list
        the non-parameter inputs to wgt_func
        if None, wgt_func uses fargs
        * must be a list since it is unpacked
        * optional: default is None
            then wgt_func uses fargs

    Key-Word Arguments:
    -------------------
    None

    Returns:
    ---------------
    residual: scalar / array
    """
    if wgt_func is None:
        return residual(p, func, fargs, measured, error)
    if wgt_args is None:
        return residual(p, func, fargs, measured, error) * wgt_func(p, *fargs)
    return residual(p, func, fargs, measured, error) * wgt_func(p, *wgt_args)
