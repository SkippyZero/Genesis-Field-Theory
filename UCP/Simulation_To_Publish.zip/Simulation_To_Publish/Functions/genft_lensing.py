#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
GenFT lensing helpers

Computes:
    - Σ(R): projected surface density
    - M2D(R): projected enclosed mass
    - α(R): reduced deflection angle
    - Einstein radius R_E

All in physical units:
    - R in kpc
    - Σ in Msun / kpc^2
    - M2D in Msun
    - α in radians
"""

import numpy as np
from scipy.integrate import quad, cumulative_trapezoid
from scipy.interpolate import InterpolatedUnivariateSpline
from scipy.optimize import brentq

from Functions.DarkMatter import GenFT as DM

# --- SI constants for lensing ---
G_SI = 6.67430e-11          # m^3 kg^-1 s^-2
C_SI = 2.99792458e8         # m s^-1
M_SUN_KG = 1.98847e30       # kg
KPC_M = 3.085677581491367e19  # m per kpc


# ----------------------------------------------------------------------
# 1. Projected surface density Σ(R)
# ----------------------------------------------------------------------

def sigma_profile(p, R, r_max_factor=50.0):
    """
    Compute Σ(R) for a GenFT halo with parameters p = (A, s).

    Parameters
    ----------
    p : lmfit.Parameters or dict
        Must contain A, s as for DM.rho / DM.M.
    R : array_like
        Projected radius in kpc.
    r_max_factor : float, optional
        Upper limit of LOS integration is r_max = r_max_factor * max(R).

    Returns
    -------
    Sigma : ndarray
        Σ(R) in Msun / kpc^2, same shape as R.
    """
    R = np.asarray(R, dtype=float)
    R = np.atleast_1d(R)
    Sigma = np.zeros_like(R)

    r_max_global = r_max_factor * np.max(R)

    for i, Ri in enumerate(R):
        # Skip R=0 exactly to avoid division issues
        if Ri <= 0.0:
            Sigma[i] = 0.0
            continue

        def integrand(r):
            # ρ(r) * r / sqrt(r^2 - R^2)
            return DM.rho(p, r) * r / np.sqrt(r**2 - Ri**2)

        # Σ(R) = 2 ∫_R^∞ ρ(r) r / sqrt(r^2 - R^2) dr
        val, _ = quad(integrand, Ri, r_max_global,
                      epsabs=0.0, epsrel=1.0e-5, limit=200)
        Sigma[i] = 2.0 * val

    return Sigma


# ----------------------------------------------------------------------
# 2. Projected enclosed mass M2D(R)
# ----------------------------------------------------------------------

def m2d_profile(p, R, Sigma=None):
    """
    Compute M2D(<R) = 2π ∫_0^R Σ(R') R' dR'.

    Parameters
    ----------
    p : lmfit.Parameters or dict
        GenFT parameters (A, s).
    R : array_like
        Radii in kpc, will be sorted in ascending order.
    Sigma : array_like, optional
        Σ(R) in Msun/kpc^2. If None, will be computed.

    Returns
    -------
    R_sorted : ndarray
        Sorted radii.
    M2D : ndarray
        Projected enclosed mass in Msun at each radius.
    """
    R = np.asarray(R, dtype=float)
    R_sorted = np.sort(R)

    if Sigma is None:
        Sigma = sigma_profile(p, R_sorted)
    else:
        Sigma = np.asarray(Sigma, dtype=float)
        Sigma = Sigma[np.argsort(R)]

    # cumulative integral: M2D(R) = 2π ∫ Σ R dR
    integrand = Sigma * R_sorted
    M2D = 2.0 * np.pi * cumulative_trapezoid(integrand, R_sorted, initial=0.0)


    return R_sorted, M2D


# ----------------------------------------------------------------------
# 3. Deflection angle α(R)
# ----------------------------------------------------------------------

def alpha_profile(p, R, D_l_Mpc, D_s_Mpc, R_sorted=None, M2D=None):
    """
    Reduced deflection angle α(R) in radians.

    Parameters
    ----------
    p : lmfit.Parameters or dict
        GenFT parameters (A, s).
    R : array_like
        Radii in kpc.
    D_l_Mpc : float
        Lens distance in Mpc.
    D_s_Mpc : float
        Source distance in Mpc (> D_l_Mpc).
    R_sorted, M2D : optional
        Precomputed M2D profile, to avoid recomputing.

    Returns
    -------
    alpha : ndarray
        Deflection α(R) in radians (same shape/order as input R).
    """
    R = np.asarray(R, dtype=float)
    R_in = np.atleast_1d(R)

    if R_sorted is None or M2D is None:
        R_sorted, M2D = m2d_profile(p, R_in)
        M2D_spline = InterpolatedUnivariateSpline(R_sorted, M2D, k=3)
    else:
        R_sorted = np.asarray(R_sorted, dtype=float)
        M2D = np.asarray(M2D, dtype=float)
        M2D_spline = InterpolatedUnivariateSpline(R_sorted, M2D, k=3)

    D_l_m = D_l_Mpc * 1.0e6 * 3.085677581491367e16  # Mpc → m
    D_s_m = D_s_Mpc * 1.0e6 * 3.085677581491367e16
    D_ls_m = D_s_m - D_l_m
    geom = D_ls_m / D_s_m

    alpha = np.zeros_like(R_in)

    for i, Ri in enumerate(R_in):
        if Ri <= 0.0:
            alpha[i] = 0.0
            continue

        M2D_R = float(M2D_spline(Ri))  # Msun
        b_m = Ri * KPC_M               # impact parameter in meters

        alpha_hat = 4.0 * G_SI * (M2D_R * M_SUN_KG) / (C_SI**2 * b_m)
        alpha[i] = geom * alpha_hat

    return alpha


# ----------------------------------------------------------------------
# 4. Einstein radius solver
# ----------------------------------------------------------------------

def einstein_radius(p, D_l_Mpc, D_s_Mpc,
                    R_min_kpc=1.0e-3, R_max_kpc=50.0):
    """
    Solve for R_E such that α(R_E) = θ(R_E) = R_E / D_l.

    Parameters
    ----------
    p : lmfit.Parameters or dict
        GenFT parameters.
    D_l_Mpc, D_s_Mpc : float
        Lens and source distances in Mpc.
    R_min_kpc, R_max_kpc : float
        Search bracket for R_E in kpc.

    Returns
    -------
    R_E_kpc : float
        Einstein radius in kpc. Returns np.nan if no root is found.
    """
    D_l_Mpc = float(D_l_Mpc)
    D_s_Mpc = float(D_s_Mpc)
    D_l_m = D_l_Mpc * 1.0e6 * 3.085677581491367e16  # Mpc → m

    # Precompute a reasonably fine grid for M2D and reuse it
    R_grid = np.logspace(np.log10(R_min_kpc), np.log10(R_max_kpc), 200)
    R_sorted, M2D = m2d_profile(p, R_grid)

    def f(Rk):
        # α(R) - θ(R)
        Rk = float(Rk)
        if Rk <= 0.0:
            return -1.0
        a = alpha_profile(p, [Rk], D_l_Mpc, D_s_Mpc,
                          R_sorted=R_sorted, M2D=M2D)[0]
        theta = (Rk * KPC_M) / D_l_m  # R / D_l
        return a - theta

    try:
        R_E = brentq(f, R_min_kpc, R_max_kpc, maxiter=200)
    except ValueError:
        # No sign change → no Einstein radius in this bracket
        R_E = np.nan

    return R_E

