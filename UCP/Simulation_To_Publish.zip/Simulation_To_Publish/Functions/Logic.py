#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""Logic Operations
"""

##############################################################################
# Importing Modules

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__license__ = "GPL"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code

def Bool(ifthis, logic, that):
    """Boolean operator function
        # TODO: AST evaluation

        Info:
        ---------------
        Boolean operator function
        alternative to a switch - style  operation

        Arguments:
        ---------------
        ifthis: 1st argument
        that: 2nd argument
        logic: str
            selects the logic type
            - "<":              less than
            - "<=":             less than or equal to
            - "=", "=="         equal
            - ">="              greater than or equal to
            - ">"               greater than
            - "!="              not equal
            - "in"              in
            - "not in", "!in"   not in
            - "and"             and
            - "or"              or
            - "is"              is
    """
    comp = {"<": lambda ifthis, that: ifthis < that,
            "<=": lambda ifthis, that: ifthis <= that,
            "=": lambda ifthis, that: ifthis == that,
            "==": lambda ifthis, that: ifthis == that,
            ">=": lambda ifthis, that: ifthis >= that,
            ">": lambda ifthis, that: ifthis > that,
            "!=": lambda ifthis, that: ifthis != that,
            "in": lambda ifthis, that: ifthis in that,
            "not in": lambda ifthis, that: ifthis not in that,
            "!in": lambda ifthis, that: ifthis not in that,
            "and": lambda ifthis, that: ifthis and that,
            "or": lambda ifthis, that: ifthis or that,
            "is": lambda ifthis, that: ifthis is that,
            }
    return comp[logic](ifthis, that)