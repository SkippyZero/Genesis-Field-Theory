# -*- coding: utf-8 -*-
# All the Functions

# Docstring
"""Convert
"""

##############################################################################
# Importing Modules

import numpy as np

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
# __copyright__ = "Copyright 2007, The Cogent Project"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Functions

def inc_to_faceon(angle, dtype="deg"):
    """converts inclined galaxy data to face on

    Info:
    ---------------
    designed for scalars and array
    |cos(angle)|

    Inputs:
    ---------------
    angle: scalar / array
        the angle(s)
    dtype: str
        data type
        accepts:
            "deg"
    Returns:
    ---------------
    adj
    """
    if dtype in ("rad", "rads", "radian", "radians"):
        pass
    elif dtype in ("deg", "degs", "degree", "degrees"):
        angle = np.deg2rad(angle)
    else:
        raise TypeError("dtype {} is not a supported format".format(dtype))

    return np.absolute(np.cos(angle))


def e_inc_to_faceon(angle, error, dtype="deg"):
    """converts error in inclined galaxy data to face on

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    angle: scalar / array
        the angle(s)
    error: scalar / array
        error in angle
        must be same dtype as angle
    dtype: str
        data type
        accepts:
            "deg"

    Returns:
    ---------------
    (|sin(angle + error)| - |sin(angle - error)|)/2
    """
    if dtype in ("rad", "rads", "radian", "radians"):
        pass
    elif dtype in ("deg", "degs", "degree", "degrees"):
        angle = np.deg2rad(angle)
        error = np.deg2rad(error)
    else:
        raise TypeError("dtype {} is not a supported format".format(dtype))

    return (np.absolute(np.sin(angle + error)) -
            np.absolute(np.sin(angle - error))) / 2


def pc_to_km(pc):
    """converts pc to km

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    pc: scalar / array

    Returns:
    ---------------
    km
    """
    return pc * 3.086e13


def kpc_to_pc(kpc):
    """converts kpc to pc

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    kpc: scalar / array

    Returns:
    ---------------
    pc
    """
    return kpc * 1e3


def kpc_to_km(pc):
    """converts kpc to km

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    kpc: scalar / array

    Returns:
    ---------------
    km
    """
    return pc_to_km(kpc_to_pc(pc))


def pc_to_kpc(pc):
    """converts pc to kpc

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    pc: scalar / array

    Returns:
    ---------------
    kpc
    """
    return pc / kpc_to_pc(1.)


def pcn_to_kpcn(pc_n, n):
    """converts pc^n to kpc^n

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    pc^n: scalar / array

    Returns:
    ---------------
    kpc^n
    """
    if n == 1:
        return pc_to_kpc(pc_n)
    else:
        return pcn_to_kpcn(pc_to_kpc(pc_n), n - 1)


def kpcn_to_pcn(kpc_n, n):
    """converts kpc^n to pc^n

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    kpc^n: scalar / array

    Returns:
    ---------------
    pc^n
    """
    if n == 1:
        return kpc_to_pc(kpc_n)
    else:
        return pcn_to_kpcn(kpc_to_pc(kpc_n), n - 1)


def perpc_to_perkpc(perpc):
    """converts 1/pc to 1/kpc

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    1/pc: scalar / array

    Returns:
    ---------------
    1/kpc
    """
    return kpc_to_pc(perpc)


def perkpc_to_perpc(perpc):
    """converts 1/kpc to 1/pc

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    1/pc: scalar / array

    Returns:
    ---------------
    1/kpc
    """
    return pc_to_kpc(perpc)


def perpcn_to_perkpcn(perpc_n, n):
    """converts 1/pc^n to 1/kpc^n

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    1/pc^n: scalar / array
    n : int

    Returns:
    ---------------
    1/kpc^n: float / array
    """
    if n == 1:
        return kpc_to_pc(perpc_n)
    else:
        return perpcn_to_perkpcn(kpc_to_pc(perpc_n), n - 1)


def perkpcn_to_perpcn(perkpc_n, n):
    """converts 1/kpc^n to 1/pc^n

    Info:
    ---------------
    designed for scalars and array

    Inputs:
    ---------------
    1/pc^n: scalar / array
    n : int

    Returns:
    ---------------
    1/kpc^n: float / array
    """
    if n == 1:
        return pc_to_kpc(perkpc_n)
    else:
        return perkpcn_to_perpcn(pc_to_kpc(perkpc_n), n - 1)
