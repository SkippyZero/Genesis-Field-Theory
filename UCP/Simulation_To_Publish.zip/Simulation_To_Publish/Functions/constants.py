# x:\GFT\Code\Simulation_To_Publish\Functions\constants.py

import numpy as np

# --- basic length conversions ---

# 1 parsec in kilometers
PC_IN_KM = 3.085677581491367e13  # km

# 1 kiloparsec in kilometers
KPC_IN_KM = 1.0e3 * PC_IN_KM     # 3.085677581491367e16 km


def kpc_to_km(r_kpc):
    """
    Convert radius in kpc to km.
    Accepts scalar or numpy array.
    """
    r = np.asarray(r_kpc, dtype=float)
    return r * KPC_IN_KM
