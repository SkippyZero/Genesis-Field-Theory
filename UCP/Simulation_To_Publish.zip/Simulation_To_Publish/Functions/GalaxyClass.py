#!/usr/bin/env python
# -*- coding: utf-8 -*-

# GalaxyClass
"""lmfit style store
"""

##############################################################################
# Importing Modules

import numpy as np
# import pandas as pd
from matplotlib import mlab
from matplotlib import colors
import lmfit as lf
# import datetime
# import copy as cp
# import urllib.request
# import warnings

# My Modules
import Functions.Convert as cn
import Functions.IO as IO
import Functions.makeSPARCDataTables as msdt

from Functions.Store import Store  # myobject, LMinterface
from Functions.Logic import Bool

import Functions.Baryons.ExpDisk2D as bar

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code

class SPARC(Store):
    """SPARC Galaxy Class for Maximal Disks

    Info:
    ---------------
    Creates:
        .params: lmfit Parameters object
            = params (argument)
            this is initialized with SPARC and
            used as the basis for future params and isn't called
        .methods: list
            list of the minimization methods
            the current code runs:
                nofit (no parameters are allowed to vary)
                ln_fit (log normal weighting with M2L parameter)
                ln_mc (log normal mcmc weighting with M2L parameter)
        .criteria: Store object
            the criteria used to select out galaxies
        .IDs: ndarray
            the galaxy IDs
        .useIDs: list
            the IDs which made the cut
        .badGals: list
            the IDs which did not make the cut
        .Rotation Curves: Store object
            accessed attribute-style via .RC or
                dict-style as [“RC”] or [“Rotation Curves”]
            Contains:
                fname: str
                    the file path where the RC data table is stored locally
                url: str
                    the url (unused) where the RC data table is stored
                header: None
                    the header (str) of the RC file is put here when _init_load_data() is called
                hdr_sep: int
                    the number of lines of header text
                note: str
                    a note about the data
        .Galaxy Sample: Store object
            accessed attribute-style via .GS or
                dict-style as [“GS”] or [“Galaxy Sample”]
            Contains:
                fname: str
                    the file path where the GS data table is stored locally
                url: str
                    the url (unused) where the GS data table is stored
                header: None
                    the header (str) of the GS file is put here when _init_load_data() is called
                hdr_sep: int
                    the number of lines of header text
                note: str
                    a note about the data
        .Preliminary
            - aka: prlm
            - RCf: full rotation curve data table
            - RC: select rotation curve data table
                only the selected galaxy are included
            - GSf: full galaxy sample data table
            - GS: select galaxy sample data table
                only the selected galaxy are included
            - params
                M2L is set to 1, same as in SPARC models

    Arguments:
    ---------------
    name: str
        the name of object.
    params: lmfit Parameters object
        the parameters for use in all minimizations
    criteria: Store object
        criteria object with inbuilt logic operators for galaxy selection
    makeprlm


    Methods:
    ---------------
    .make_method_paths()
        default paths for loading &/or saving
    .save_method()
        saves method via a given dictionary of paths
    .make_prlm()
        make / load preliminary data from SPARC database
    .apply_criteria()
        apply selection criteria to preliminary data
    .make_fiducial()
        make /load data tables with given params
    .make_method()
        makes / loads a new fit method
    .update_method()
        updates a fit method to reflect param values
        param values in self.galx[ID].methods[method] automatically used or
        parameters may be passed
    .make_select_view()
        returns a data table of galaxies not eliminated by .criteria
    .make_comparison_view()
        a data table of fiducial with *only* updated M2L values

    ._split_into_galaxies()
        Adding into individual galaxy attributes to store fit parameters, etc.
    ._apply_criteria()
        underlying method to apply_criteria
        applies the given criteria

    Property Update Methods:
    ---------------
    .Vbar: function
        calls bar.Vbar(p, )
    .e_Vbar: function
        calls bar.e_Vbar(p, )
    .Mbar: function
        calls bar.Mbar(p, )
    .e_Mbar: function
        calls bar.e_Mbar(p, )
    .SBbar: function
        calls bar.SBbar(p, )
    .e_SBbar: function
        calls bar.e_SBbar(p, )
    .Vdisk: function
        updates Vdisk by M2L dependence
    .e_Vdisk: function
        updates e_Vdisk by M2L dependence
    .Vbul: function
        updates Vbul by M2L dependence
    .e_Vbul: function
        updates e_Vbul by M2L dependence
    .SBdisk: function
        updates SBdisk by M2L dependence
    .e_SBdisk: function
        updates e_SBdisk by M2L dependence
    .SBbul: function
        updates SBbul by M2L dependence
    .e_SBbul: function
        updates e_SBbul by M2L dependence
    .SB0: function
        updates SB0 by M2L dependence
    .e_SB0: function
        updates e_SB0 by M2L dependence
    """

    def __init__(self, name, params, criteria=None,
                 makeprlm={}, aplycrit={}, fiducial={}):
        """
        makeprlm={
            "actions": "load",
            "paths": {
                "RCf": "Output/Tables/Preliminary RC Table",
                "GSf": "Output/Tables/Preliminary GS Table"}},
         aplycrit={
            "actions": "load",
            "paths": {
                "RC": "Output/Tables/Preliminary RC Table select",
                "GS": "Output/Tables/Preliminary GS Table select",
                "RCf": "Output/Tables/Preliminary RC Table",
                "GSf": "Output/Tables/Preliminary GS Table",
                "method": "Output/Tables/Preliminary store"}},
         fiducial={
            "actions": "load",
            "paths": {
                "RC": "Output/Tables/Fiducial RC Table select",
                "GS": "Output/Tables/Fiducial GS Table select",
                "RCf": "Output/Tables/Fiducial RC Table",
                "GSf": "Output/Tables/Fiducial GS Table",
                "RCc": "Output/Tables/Fiducial RC Table comp",
                "GSc": "Output/Tables/Fiducial GS Table comp",
                "method": "Output/Tables/Fiducial store"}}
        """
        assert isinstance(name, str)
        assert isinstance(params, type(lf.Parameters()))
        assert isinstance(criteria, type(Store()))
        assert isinstance(makeprlm, dict)
        assert isinstance(aplycrit, dict)
        assert isinstance(fiducial, dict)

        super(SPARC, self).__init__(name, None)

        self.params = params.copy()
        self.methods = []  # where the .fit methods are stored
        self.IDs = "None until .make_prlm() is run"

        # preliminary 'fit'. Where SPARC data is initialized
        self.add("Preliminary", aka="prlm",
                 RCf=None, RC=None, GSf=None, GS=None,
                 params=params.copy())
        self.prlm.params["M2L"].value = 1  # SPARC tables are at M2L = 1

        # Criteria related class variables
        self.criteria = criteria
        self.useIDs = []
        self.badGals = []

        # Runs data table constructors
        self.make_prlm(**makeprlm)
        self._split_into_galaxies()
        self.apply_criteria(**aplycrit)

        print("\nGalaxies Initialized\n")

        self.make_fiducial(**fiducial)

    # _make_method_paths
    # -------------------------------------------------------------------------
    def _make_method_paths(self, method, print_status=False,
                           pathbase="Output/Tables/",
                           total=True, info=True,
                           RCf=True, RC=True, RCc=True,
                           GSf=True, GS=True, GSc=True,
                           onlyTrues=None):
        """Makes default paths for loading &/or saving

        Info:
        ---------------
        full data table path in "... Table"
        select data table path in "... Table select"
        comparison data table path in "... Table com"

        path for complete Store object in " store"
            this allows for I/O of the whole set of data tables at once
        path for per galaxy Store object in " info"
            this allows for I/O of fit info objects into each galaxy in .galx

        Arguments:
        ---------------
        method: str
            the fit method name
        print_status: bool
            print information
        pathbase: str
            the pathbase, file path from execution file to save location
        total: bool
            make whole method path
            defualt: True
        info: bool
            make info path
            defualt: True,
        RCf: bool
            make RCf path
            defualt: True
        RC: bool
            make RC path
            defualt: True
        RCc: bool
            make RCc path
            defualt: True
        GSf: bool
            make GSf path
            defualt: True
        GS: bool
            make GS path
            defualt: True
        GSc: bool
            make GSc path
            defualt: True
        onlyTrues: array-like
            list of str, which to set to True
            overrides any in: total -> GSc

        Returns:
        ---------------
        method: pathbase + method + " store"
        info: pathbase + method + " info"
        RC paths are:
            RCf: pathbase + method +  " RC Table"
            RC: pathbase + method +  " RC Table select"
            RCc: pathbase + method +  " RC Table comp"
        GS paths are:
            GSf: pathbase + method +  " GS Table"
            GS: pathbase + method +  " GS Table select"
            GSc: pathbase + method +  " GS Table comp"
        """
        assert isinstance(method, str)
        assert isinstance(print_status, bool)
        assert isinstance(pathbase, str)

        if print_status is True:
            print("\tMaking default paths")

        if onlyTrues is not None:
            total = True if "total" in onlyTrues else False
            info = True if "info" in onlyTrues else False
            RCf = True if "RCf" in onlyTrues else False
            RC = True if "RC" in onlyTrues else False
            RCc = True if "RCc" in onlyTrues else False
            GSf = True if "GSf" in onlyTrues else False
            GS = True if "GS" in onlyTrues else False
            GSc = True if "GSc" in onlyTrues else False

        paths = {}
        tmp = pathbase + method

        if total is True:
            paths["method"] = tmp + " store"
        if info is True:
            paths["info"] = tmp + " info"
        if RCf is True:
            paths["RCf"] = tmp + " RC Table"
        if GSf is True:
            paths["GSf"] = tmp + " GS Table"
        if RC is True:
            paths["RC"] = tmp + " RC Table select"
        if RCc is True:
            paths["RCc"] = tmp + " RC Table comp"
        if GS is True:
            paths["GS"] = tmp + " GS Table select"
        if GSc is True:
            paths["GSc"] = tmp + " GS Table comp"

        return paths

    # save_method
    # -------------------------------------------------------------------------
    def save_method(self, method, paths=None, save_pickle=False):
        """saves method via a given dictionary of paths

        Info:
        ---------------
        saves to .pickle file
        if it's a dataframe, also saves .csv and .html

        paths["method"]: str
            path for complete Store object in " store"
            this allows for I/O of the whole set of data tables at once
        paths["info"]
            path for per galaxy Store object in " info"
            this allows for I/O of fit info objects into each galaxy in .galx

        Arguments:
        ---------------
        method: str
            the fit method name
        paths: None or dict
            dictionary of paths for saving fit methods
            if None, uses default paths from ._make_method_paths()
        save_pickle: bool
            whether to save dataframes as .pickle files

        Returns:
        ---------------
        None, all saving done in place
        """
        assert isinstance(method, str)
        assert isinstance(save_pickle, bool)

        # Path Construction
        if paths is None:  # make default paths if None
            paths = self._make_method_paths(method)
        assert isinstance(paths, dict)

        # saving 'method'
        method_path = paths.pop("method", False)
        if method_path is not False:  # save method
            IO.to_pickle(self[method], method_path, ext="pickle")

        # saving 'info'
        info_path = paths.pop("info", False)
        if info_path is not False:  # save info
            d = {}
            for ID in self.IDs:  # iterating thru galaxies
                d[ID] = self.galx[ID].methods[self[method].aka]
            IO.to_pickle(d, info_path, ext="pickle")

        # Saving path itmes other than 'method' and 'info'
        for key, val in paths.items():
            if val is not None:
                IO.save_df(self[method][key], val, save_pickle=save_pickle)

    # make_prlm
    # -------------------------------------------------------------------------
    def make_prlm(self, actions="load", paths=None,
                  pathbase="Output/Tables/", save_pickle=True,
                  RCdatabasepath="Databases/SPARC/MassModels_Lelli2016c.mrt",
                  GSdatabasepath="Databases/SPARC/Table1wbulge.mrt"):
        """make / load preliminary data from SPARC database

        Info:
        ---------------
        make / load preliminary data from SPARC database
        if file cannot be loaded from *paths["RCf"] + " & info.pickle"*
            a new file will be made and saved at this location

        __init__ default unpacks and passes
        makeprlm={"actions": "load",
                  "paths": {"RCf": "Output/Tables/Preliminary RC Table",
                            "GSf": "Output/Tables/Preliminary GS Table"}}

        Arguments:
        ---------------
        actions: array-type or str
            the actions to perform
            - load: load data tables
                need "load" or "make"
            - make: make data tables
                need "load" or "make"
                will overwrite loaded data
            - save: save data tables
            defualt is ("load", "save")
        paths: None or dict
            dictionary of paths for saving fit methods
            if None, uses default paths from ._make_method_paths()
        pathbase: str
            the pathbase, file path from execution file to save location
            only used if 'paths' are None, to construct paths dict
        save_pickle: bool
            whether to save dataframes as .pickle files
            default: False

        Returns:
        ---------------
        None, done in place
        """
        print("Making Preliminary")
        assert isinstance(pathbase, str)
        assert isinstance(save_pickle, bool)
        # Path Construction
        if paths is None:  # make default paths
            paths = self._make_method_paths("Preliminary", print_status=True,
                                            pathbase=pathbase,
                                            onlyTrues=("RCf", "GSf"))
        assert isinstance(paths, (dict, str))

        # Loading
        if "load" in actions:
            # Loading RC data
            try:
                d = IO.from_pickle(paths["RCf"] + " & info", ext="pickle")
            except ImportError:
                print("there's a problem with the data file. Delete it and rerun to get a new file")
            except FileNotFoundError:
                print("\t{} file not found.".format(paths["RCf"] + " & info"),
                      "\tMaking new RC table at this location", sep="\n")
                saveRC = paths["RCf"] if "save" in actions else False
                RCf, RC = msdt.make_RC(self.prlm.params, full_output=True,
                                       fpath=saveRC,
                                       save_pickle=save_pickle,
                                       databasepath=RCdatabasepath)
                actions = "save"
                print("\tNew RCf made")
            else:
                RC, RCf = d["RC"], d["RCf"]
            finally:
                self.transfer(RC, aka="RC")  # transering to self
                print("\tRCf loaded")

            # Loading GS data
            try:
                d = IO.from_pickle(paths["GSf"] + " & info", ext="pickle")
            except ImportError:
                print("there's a problem with the data file. Delete it and rerun to get a new file")
            except FileNotFoundError:
                print("\t{} file not found.".format(paths["GSf"] + " & info"),
                      "\tMaking new GS table at this location", sep="\n")
                saveGS = paths["GSf"] if "save" in actions else False
                GSf, GS = msdt.make_GS(self.prlm.params, full_output=True,
                                       fpath=saveGS,
                                       save_pickle=save_pickle,
                                       databasepath=GSdatabasepath)
                actions = "save"
                print("\tNew GSf made")
            else:
                GS, GSf = d["GS"], d["GSf"]
            finally:
                self.transfer(GS, aka="GS")  # transering to self
                print("\tGSf loaded")

        elif "make" in actions:
            RCf, RC, GSf, GS = \
                msdt.make_prlm_DataTables(self.prlm.params, full_output=True,
                                          RCpath=paths["RCf"],
                                          GSpath=paths["GSf"],
                                          save_pickle=save_pickle,
                                          RCdatabasepath=RCdatabasepath,
                                          GSdatabasepath=GSdatabasepath)
            self.transfer(RC, aka="RC")  # transering to self
            self.transfer(GS, aka="GS")  # transering to self
            print("\tNew RCf and GSf made")

        else:
            raise Exception("need 'load' or 'make' in *actions*")

        self.prlm.RCf = RCf  # transering RCf to preliminary
        self.prlm.GSf = GSf  # transering GSf to preliminary

        if "save" in actions:
            # Saving Methods
            self.save_method("Preliminary", paths, save_pickle=save_pickle)

            # Saving .info files
            IO.to_pickle({"RC": self.RC, "RCf": self.prlm.RCf},
                         paths["RCf"] + " & info", ext="pickle")

            IO.to_pickle({"GS": self.GS, "GSf": self.prlm.GSf},
                         paths["GSf"] + " & info", ext="pickle")

        # The IDs
        self.IDs = self.prlm.GSf["ID"].unique()

        if "load" in actions:
            print("... Preliminary loaded")
        elif "make" in actions:
            print("... Preliminary made")

    # apply_criteria
    # -------------------------------------------------------------------------
    def apply_criteria(self, actions="load", paths=None,
                       save_pickle=True):
        """Apply criteria to preliminary SPARC data or loads select data table
        from given paths

        Info:
        ---------------
        Applies the given criteria to preliminary SPARC data
        or loads select data table from given paths

        __init__ default passes
        paths={
           "RC": "Output/Tables/Preliminary RC Table select",
           "GS": "Output/Tables/Preliminary GS Table select",
           "RCf": "Output/Tables/Preliminary RC Table",
           "GSf": "Output/Tables/Preliminary GS Table"}

        Arguments:
        ---------------
        actions: array-type or str
            the actions to perform
            - "load": load from location RC/GSpath
                if can't load, will use ("apply", "save", "all")
            - "apply" / "make": apply criteria. will NOT auto-save
                apply criteria to preliminary dataframe
            - "save": save to 'paths' location
                save dataframe of selected data
                - "all": save dataframe of selected data AND modified full table
        paths: None or dict
            dictionary of paths for saving fit methods
            if None, uses default paths from ._make_method_paths()
        save_pickle: bool
            whether to save dataframes as .pickle files
            default: False

        Returns:
        ---------------
        None, done in place
        """
        print("\nLoading / Applying Criteria")
        assert isinstance(save_pickle, bool)
        # Path Construction
        if paths is None:  # make default paths
            paths = self._make_method_paths("Preliminary", print_status=True,
                                            RCc=False, GSc=False, info=False)
        assert isinstance(paths, (dict, str))

        if "load" in actions:
            # RC
            try:
                self.prlm.RC = IO.from_pickle(paths["RC"], ext="pickle")
            except FileNotFoundError:
                print("\t{} file not found.\n".format(paths["RC"]),
                      "\tMaking new RC and GS tables at:\n",
                      "\t  - RC: {}\n".format(paths["RC"]),
                      "\t  - GS: {}\n".format(paths["GS"]))
                actions = ("apply", "save", "all")
            else:
                print("\tRC loaded")
            # GS
            try:
                self.prlm.GS = IO.from_pickle(paths["GS"], ext="pickle")
            except FileNotFoundError:
                print("\t{} file not found.\n".format(paths["GS"]),
                      "\tMaking new RC and GS tables at:\n",
                      "\t  - RC: {}\n".format(paths["RC"]),
                      "\t  - GS: {}\n".format(paths["GS"]))
                actions = ("apply", "save", "all")
            else:
                print("\tGS loaded")
                self.useIDs = self.prlm.GS["ID"].values

        if "apply" in actions or "make" in actions:
            print("\tApplying criteria")
            self._apply_criteria()

        if "save" in actions:
            print("\tSaving criteria:", end=" ")
            if "all" in actions:
                print("full dataframe")

                self.save_method("Preliminary", paths, save_pickle=save_pickle)

                IO.to_pickle({"RC": self.RC, "RCf": self.prlm.RCf},
                             paths["RCf"] + " & info", ext="pickle")

                IO.to_pickle({"GS": self.GS, "GSf": self.prlm.GSf},
                             paths["GSf"] + " & info",)
            else:
                print("select view")
                IO.save_df(self.prlm.RC, paths["RC"], save_pickle=save_pickle)
                IO.save_df(self.prlm.GS, paths["GS"], save_pickle=save_pickle)

        if "load" in actions:
            print("... Criteria loaded")
        elif "apply" in actions or "make" in actions:
            print("... Criteria applied")

    # make_fiducial
    # -------------------------------------------------------------------------
    def make_fiducial(self, actions="load", paths=None,
                      save_pickle=False):
        """makes a fiducial "fit". Updates values from .prlm to reflect
            the given params

            Info:
            ---------------
            makes a fiducial "fit". Updates values from .prlm to reflect
            the given params

            Arguments:
            ---------------
            actions: array-type or str
                the actions to perform
                - load: load data tables
                    need "load" or "make"
                - make: make data tables
                    need "load" or "make"
                    will overwrite loaded data
                - save: save data tables
                defualt is ("load", "save")
            save_pickle: bool
                whether to save dataframes as .pickle files
                default: False

            Returns:
            ---------------
            None. all edits made in place
        """

        print("Making Fiducial:")
        assert isinstance(save_pickle, bool)
        # Path Construction
        if paths is None:  # make default paths
            paths = self._make_method_paths("Fiducial", info=False)
        assert isinstance(paths, (dict, str))

        # Loading Fiducial
        if "load" in actions:
            try:
                fid = IO.from_pickle(paths["method"], ext="pickle")
            except FileNotFoundError:
                print("\t{} file not found.\n".format(paths["method"]),
                      "\tMaking new RC and GS tables at:\n",
                      "\t  - RC: {}\n".format(paths["RC"]),
                      "\t  - GS: {}\n".format(paths["GS"]))
                actions = ("make", "save")
            else:
                self.transfer(fid, aka="fid")
                print("\tFiducial Loaded")

        # Making Fiducial
        if "make" in actions:
            self.add("Fiducial", aka="fid", note="Fiducial at seeded params",
                     params=self.params.copy(),
                     RCf=None, RC=None,
                     GSf=None, GS=None)

            self.fid.RCf = self.prlm.RCf.copy()
            self.fid.GSf = self.prlm.GSf.copy()

            # Updating M2L-dependent properties
            for ID in self.IDs:
                self.update_method("fid", ID, self.galx[ID],
                                   self.galx[ID].params)
            print("\tRCf & GSf made")

            # Make Select View
            self.make_select_view("Fiducial", actions="make", paths=paths)
            print("\tRc & GS made")

            # Make Comparison View
            self.make_comparison_view("Fiducial", paths=paths)
            print("\tRCc & GSc made")

        # Saving
        if "save" in actions:
            print("\tSaving Fiducial")
            self.save_method("fid", paths, save_pickle=save_pickle)

        if "load" in actions:
            print("... Fiducial loaded")
        elif "make" in actions:
            print("... Fiducial made")

    # make_method
    # -------------------------------------------------------------------------
    def make_method(self, method, aka, actions="load",
                    paths=None, do_fit_args=None,
                    full_output=False):
        """makes a fit method.

        Info:
        ---------------

        Arguments:
        ---------------
        method: str
            the fit method
        aka: str
            reference name for access
        actions: array-type or str
            the actions to perform
            - load: load data tables
                need "load" or "make"
            - make: make data tables
                need "load" or "make"
                will overwrite loaded data
            - save: save data tables
            defualt is ("load", "save")
        paths: None or dict
            dictionary of paths for saving fit methods
            if None, uses default paths from ._make_method_paths()
        do_fit_args: None or list
            the arguments to be passed to the minimizer and emcee functions

        Returns:
        ---------------
        None. all edits made in place
        """
        print("Making {}:".format(method))
        assert isinstance(method, str)
        assert isinstance(aka, str)
        assert isinstance(full_output, bool)
        # Path Construction
        if paths is None:  # make default paths
            paths = self._make_method_paths(method)
        assert isinstance(paths, dict)

        # Checking doesn't already exist
        if aka in self.methods:
            print("\tMethod already exists. Overwriting.")
        else:
            self.methods.append(aka)

        self.add(method, aka=aka)

        if "load" in actions:
            if "method" in paths:
                print("\tLoading method...", end=" ")
                try:
                    obj = IO.from_pickle(paths["method"], ext="pickle")
                except FileNotFoundError:  # b/c "method" auto-made, might not work
                    print("Could not load")
                    actions = "make"
                else:
                    self.transfer(obj, aka=aka)
                    # load_indiv = False
                    print("{} loaded from 'method' path".format(method))

            if "info" in paths:
                print("\tLoading info...", end=" ")
                try:
                    info = IO.from_pickle(paths["info"], ext="pickle")
                except FileNotFoundError:  # b/c "method" auto-made, might not work
                    print("Could not load")
                    actions = "make"
                else:
                    for ID in self.IDs:
                        galx = self.galx[ID]
                        galx.methods.append(aka)
                        galx.methods.transfer(info[ID], aka=aka)
                    # load_indiv = False
                    print("loaded from {} 'info' path".format(method))

        if "make" in actions:
            print("\tMaking RC & GS tables")
            self[aka].addto(RCf=self.fid.RCf.copy(), RC=None, RCc=None,
                            GSf=self.fid.GSf.copy(), GS=None, GSc=None,
                            do_fit_args=do_fit_args)

        if full_output is True:
            return actions

    # Property Update Functions
    ###########################################################################
    def Vbar(self, p, ID):
        """Vbar reference function
            calls bar.Vbar()"""
        return bar.Vbar(p,
                        self.prlm.RCf.loc[ID, "Vdisk"],
                        self.prlm.RCf.loc[ID, "Vbul"],
                        self.prlm.RCf.loc[ID, "Vgas"])

    def e_Vbar(self, p, ID):
        """e_Vbar reference function
        calls bar.e_Vbar()"""
        return bar.e_Vbar(p,
                          self.prlm.RCf.loc[ID, "Vdisk"],
                          self.prlm.RCf.loc[ID, "e_Vdisk"],
                          self.prlm.RCf.loc[ID, "Vbul"],
                          self.prlm.RCf.loc[ID, "e_Vbul"],
                          self.prlm.RCf.loc[ID, "Vgas"])

    def Mbar(self, p, ID):
        """Mbar reference function
        calls bar.Mbar()"""
        return bar.Mbar(p, self.prlm.GSf.loc[ID, "L[3.6]"])

    def e_Mbar(self, p, ID):
        """e_Mbar reference function
        calls bar.e_Mbar()"""
        return bar.e_Mbar(p,
                          self.prlm.GSf.loc[ID, "L[3.6]"],
                          self.prlm.GSf.loc[ID, "e_L[3.6]"])

    def SBbar(self, p, ID):
        """SBbar reference function
        calls bar.SBbar()"""
        return bar.SBbar(p,
                         self.prlm.GSf.loc[ID, "Rp"],
                         self.prlm.GSf.loc[ID, "L[3.6]"])

    def e_SBbar(self, p, ID):
        """e_SBbar reference function
        calls bar.e_SBbar()"""
        return bar.e_SBbar(p,
                           self.prlm.GSf.loc[ID, "Rp"],
                           self.prlm.GSf.loc[ID, "L[3.6]"],
                           self.prlm.GSf.loc[ID, "e_L[3.6]"])

    def Vdisk(self, p, ID):
        """Vdisk reference function
        corrects Vdisk by changes in M2L"""
        return self.prlm.RCf.loc[ID, "Vdisk"] * np.sqrt(p["M2L"].value)

    def e_Vdisk(self, p, ID):
        """e_Vdisk reference function
        corrects Vdisk uncertainty by changes in M2L"""
        e_M2L = float(p["M2L"].stderr) if p["M2L"].stderr is not None else 0.
        return (self.prlm.RCf.loc[ID, "Vdisk"] * e_M2L /
                (2 * np.sqrt(p["M2L"].value)))

    def Vbul(self, p, ID):
        """Vbul reference function
        corrects Vbul by changes in M2L"""
        return self.prlm.RCf.loc[ID, "Vbul"] * np.sqrt(p["M2Lb"].value)

    def e_Vbul(self, p, ID):
        """e_Vbul reference function
        corrects Vbul uncertainty by changes in M2L"""
        e_M2Lb = float(p["M2Lb"].stderr) if p["M2Lb"].stderr is not None else 0.
        return (self.prlm.RCf.loc[ID, "Vbul"] * e_M2Lb /
                (2 * np.sqrt(p["M2Lb"].value)))

    def SBdisk(self, p, ID):
        """SBdisk reference function
        corrects SBdisk by changes in M2L"""
        return self.prlm.RCf.loc[ID, "SBdisk"] * p["M2L"].value

    def e_SBdisk(self, p, ID):
        """e_SBdisk reference function
        corrects SBdisk uncertainty by changes in M2L"""
        e_M2L = float(p["M2L"].stderr) if p["M2L"].stderr is not None else 0.
        return (self.prlm.RCf.loc[ID, "SBdisk"] * e_M2L)

    def SBbul(self, p, ID):
        """SBbul reference function
        corrects SBbul by changes in M2L"""
        return self.prlm.RCf.loc[ID, "SBbul"] * p["M2Lb"]

    def e_SBbul(self, p, ID):
        """e_SBbul reference function
        corrects SBbul uncertainty by changes in M2L"""
        e_M2Lb = float(p["M2Lb"].stderr) if p["M2Lb"].stderr is not None else 0.
        return self.prlm.RCf.loc[ID, "SBbul"] * e_M2Lb

    def SB0(self, p, ID):
        """SB0 reference function
        corrects SB0 by changes in M2L"""
        return self.prlm.GSf.loc[ID, "SB0"] * p["M2L"]

    def e_SB0(self, p, ID):
        """e_SB0 reference function
        corrects SB0 uncertainty by galaxy inclination uncertainty
            and changes in M2L"""
        e_M2L = float(p["M2L"].stderr) if p["M2L"].stderr is not None else 0.

        dM2L = self.prlm.GSf.loc[ID, "SB0"] * e_M2L
        dinc = cn.e_inc_to_faceon(self.prlm.GSf.loc[ID, "inc"],
                                  self.prlm.GSf.loc[ID, "e_inc"],
                                  dtype="deg")
        return np.sqrt(dM2L**2 + dinc**2)

    # Initialization Functions
    ###########################################################################

    # _split_into_galaxies
    # -------------------------------------------------------------------------
    def _split_into_galaxies(self):
        """Adding into individual galaxy attributes to store fit parameters, etc.

            Info:
            ---------------
            Adding into individual galaxy attributes to store
                fit parameters, etc.
            galaxies are stored as Store Class object in the *galx*
                instance of *self*
            the passed lmfit parameters are copied into the galaxy
                self.galx[galaxy ID].params
            creates *methods*, an empty list to store the fit methods
                applied to the galaxy
            galaxies initialized with *use* = True

            Arguments:
            ---------------
            None

            Returns:
            ---------------
            None
        """
        # Each Galaxy
        self.add("galx", info="all the galaxy data ordered by galaxy")

        # Iterating through galaxies
        for ID in self.IDs:  # iter thru galaxies by name
            self.galx.add(ID, use=True)  # add galaxy

            galx = self.galx[ID]

            # Galaxy parameters
            params = self.params.copy()

            # Seeding Parameter Values
            params["Rd"].value = self.prlm.GSf.loc[ID, "Rdisk"]
            params["sig0"].value = self.prlm.GSf.loc[ID, "SB0"]

            galx.params = params

            # list of fit methods used for this galaxy
            galx.add("methods", [])

            # Velocity Equations
            galx.add("Vdisk", func=lambda p, iD=ID: self.Vdisk(p, iD))
            galx.add("e_Vdisk", func=lambda p, iD=ID: self.e_Vdisk(p, iD))

            galx.add("Vbul", func=lambda p, iD=ID: self.Vbul(p, iD))
            galx.add("e_Vbul", func=lambda p, iD=ID: self.e_Vbul(p, iD))

            galx.add("Vbar", func=lambda p, iD=ID: self.Vbar(p, iD))
            galx.add("e_Vbar", func=lambda p, iD=ID: self.e_Vbar(p, iD))

            # Mass Equations
            galx.add("Mbar", func=lambda p, iD=ID: self.Mbar(p, iD))
            galx.add("e_Mbar", func=lambda p, iD=ID: self.e_Mbar(p, iD))

            # Surface Brightness Equations
            galx.add("SBdisk", func=lambda p, iD=ID: self.SBdisk(p, iD))
            galx.add("e_SBdisk", func=lambda p, iD=ID: self.e_SBdisk(p, iD))

            galx.add("SBbul", func=lambda p, iD=ID: self.SBbul(p, iD))
            galx.add("e_SBbul", func=lambda p, iD=ID: self.e_SBbul(p, iD))

            galx.add("SB0", func=lambda p, iD=ID: self.SB0(p, iD))
            galx.add("e_SB0", func=lambda p, iD=ID: self.e_SB0(p, iD))

            galx.add("SBbar", func=lambda p, iD=ID: self.SBbar(p, iD))
            galx.add("e_SBbar", func=lambda p, iD=ID: self.e_SBbar(p, iD))

    # _apply_criteria
    # -------------------------------------------------------------------------
    def _apply_criteria(self):
        """Applies the criteria in .criteria

            RC := Rotation Curve
            GS := Galaxy Sample

            Info:
            ---------------
            finds the galaxies to be cut
            the criteria is a Store object
            it thus has a name and value and is most easily accessed
                by an aka shorthabd
            ._apply_criteria() uses .value as the cut criteria and the
                kwargs "ifthis", "logic", "where", and optionally "operation"
                to make the selection

            ex: criteria = Store("cut criteria")
                criteria.add("Inclination Cut", 30, aka="IncCut", ifthis="inc",
                             logic="<", where="GS")
                criteria.add("Bulge Component", ("NGC4051", "NGC0891"),
                             aka="iBulge", ifthis="ID", logic="in", where="GS")
                criteria.add("Dist Error", .2, aka="e_D", ifthis=("e_D", "D"),
                             logic=">", where="GS",
                             operation=lambda *arg: arg[0] / arg[1])

            the selection is applied so that if
                operation(where[ifthis]) (relational logic operator) .value
                is satisfied, the galaxy is cut
                ex: for no "operation"
                    where=GS, ifthis="inc", logic="<", .value = 30
                    => self.prlm[GS][inc] < 30  => cut if inc angle is < 30°
                ex: for a division "operation"
                    ifthis=("e_D", "D"), logic=">", where="GS",
                    operation=lambda *arg: arg[0] / arg[1]), .value=.2
                    => self.prlm[GS][e_D] / self.prlm[GS][D] > .2
                    => all galaxies with fractional error in D is > .2 are cut

            colorcodes the galaxies by the cut criteria (the last one a galaxy matches)
            keeps a str log of which criteria a galaxy matches

            Arguments:
            ---------------
            None

            Returns:
            ---------------
            None
        """
        # getting criteria color bar
        length = len(self.criteria.keys(only_vars=True))
        cmap = colors.LinearSegmentedColormap.from_list("Cut Colors",
                                                        (np.array([222, 45, 38, .2 * 255]) / 255,
                                                         np.array([222, 220, 38, .2 * 255]) / 255),
                                                        N=length)
        rcmap = lambda i: tuple([float("{:.2}".format(v)) for v in cmap(i)])

        # Applying criteria
        for ID in self.IDs:
            galx = self.galx[ID]

            # Applying the Criteria
            applicable_crit = ""
            for i, crit in enumerate(self.criteria.iter()):
                if crit.where in ("GS", "GSf"):
                    if isinstance(crit.ifthis, str):
                        prop = self.prlm.GSf.loc[ID, crit.ifthis]
                    else:
                        ifthis = crit.ifthis
                        argsf = [self.prlm.GSf.loc[ID, it] for it in ifthis]

                        prop = crit.operation(*argsf)

                else:
                    print(crit.name, " failed")

                if Bool(prop, crit.logic, crit.value):
                    galx.use = False
                    self.prlm.GSf.loc[ID, "use"] = False
                    applicable_crit += "{} ".format(crit.aka)
                    self.prlm.GSf.loc[ID, "color"] = "rgba" + str(rcmap(i))

            if galx.use is False:  # it matched some criteria
                self.prlm.GSf.loc[ID, "crit"] = applicable_crit

            if galx.use is True:
                self.useIDs.append(ID)
            else:
                self.badGals.append(ID)

        self.useIDs = np.array(self.useIDs)

        self.make_select_view("prlm")

    # update_method
    # -------------------------------------------------------------------------
    def update_method(self, method, ID, galx, p=None):
        """update all M2L affected functions when a fit is implemented

        Info:
        ---------------
        updates anything which is a function of M2L

        Arguments:
        ---------------
        method: str
            the fit method
        ID: str
            the galaxy ID
        galx: galaxy instance
            has the update functions in it
        p: lmfit Parameters object
            needs an M2L
            default: None, loads galx.params

        Returns:
        ---------------
        None. all edits made in place
        """
        assert isinstance(method, str)
        assert isinstance(ID, str)

        if p is None:
            p = galx.params

        e_M2L = float(p["M2L"].stderr) if p["M2L"].stderr is not None else 0.
        e_M2Lb = (float(p["M2Lb"].stderr) if p["M2Lb"].stderr
                  is not None else 0.)

        # Params
        self[method].RCf.loc[ID, ["M2L", "e_M2L"]] = p["M2L"].value, e_M2L
        self[method].RCf.loc[ID, ["M2Lb", "e_M2Lb"]] = p["M2Lb"].value, e_M2Lb

        self[method].GSf.loc[ID, ["M2L", "e_M2L"]] = p["M2L"].value, e_M2L
        self[method].GSf.loc[ID, ["M2Lb", "e_M2Lb"]] = p["M2Lb"].value, e_M2Lb

        # RC
        for prop in ("Vdisk", "e_Vdisk", "Vbul", "e_Vbul", "Vbar", "e_Vbar",
                     "SBdisk", "e_SBdisk", "SBbul", "e_SBbul"):
            self[method].RCf.loc[ID, prop] = np.array(galx[prop].func(p))

        if any(self[method].RCf.loc[ID, 'e_Vdisk'] > self[method].RCf.loc[ID, 'Vdisk']):
            self[method].RCf.loc[ID, 'e_Vdisk'] = .2 * self[method].RCf.loc[ID, 'Vdisk']

        # Peak
        pk_ind = int(np.where(self[method].RCf.loc[ID, "Vbar"] ==
                              max(self[method].RCf.loc[ID, "Vbar"]))[0][0])
        self[method].GSf.loc[ID, "pk_ind"] = pk_ind

        # Rp
        Rp = self[method].RCf.loc[(ID, pk_ind), "R"]
        self[method].GSf.loc[ID, "Rp"] = Rp

        # GS
        # Vbar Peak
        Vb, e_Vb = self[method].RCf.loc[(ID, pk_ind), ["Vbar", "e_Vbar"]]
        self[method].GSf.loc[ID, ["Vb", "e_Vb"]] = Vb, e_Vb

        # Disk Maximality
        Vp, e_Vp = self[method].GSf.loc[ID, ["Vp", "e_Vp"]]
        e_Vb_Vp = np.sqrt((e_Vb / Vp)**2 + (Vb * e_Vp / Vp**2)**2)
        self[method].GSf.loc[ID, ["Vb/Vp", "e_(Vb/Vp)"]] = (Vb / Vp), e_Vb_Vp

        # Acceleration
        e_V2b_Rp = np.sqrt((2 * Vb * e_Vb / Rp)**2)
        self[method].GSf.loc[ID, "V2b/Rp"] = Vp**2 / Rp
        self[method].GSf.loc[ID, "e_(V2b/Rp)"] = e_V2b_Rp

        e_V2p_Rp = np.sqrt((2 * Vp * e_Vp / Rp)**2)
        self[method].GSf.loc[ID, "V2p/Rp"] = Vp**2 / Rp
        self[method].GSf.loc[ID, "e_(V2p/Rp)"] = e_V2p_Rp

        for prop in ("SB0", "e_SB0", "Mbar", "e_Mbar", "SBbar", "e_SBbar"):
            self[method].GSf.loc[ID, prop] = galx[prop].func(p)

    # make_select_view
    # -------------------------------------------------------------------------
    def make_select_view(self, method, actions="load", paths=None,
                         save_pickle=False):
        """makes a selected view without cut galaxies

        Info:
        ---------------
        makes a selected view without cut galaxies

        Arguments:
        ---------------
        method: str
            the fit method
        actions: array-type or str
            the actions to perform
            - load: load data tables
                need "load" or "make"
            - make: make data tables
                need "load" or "make"
                will overwrite loaded data
            - save: save data tables
            defualt is ("load", "save")
        paths: None or dict
            dictionary of paths for saving fit methods
            if None, uses default paths from ._make_method_paths()
        save_pickle: bool
            whether to save dataframes as .pickle files
            default: False

        Returns:
        ---------------
        None. All edits made in place
        """
        assert isinstance(method, str)
        assert isinstance(save_pickle, bool)
        # Path Construction
        if paths is None:  # make default paths
            paths = self._make_method_paths(method, RCf=False, RCc=False,
                                            GSf=False, GSc=False,
                                            total=False, info=False)
        assert isinstance(paths, dict)

        if "load" in actions:
            try:  # RC
                self[method].RC = IO.from_pickle(paths["RC"], ext="pickle")
            except FileNotFoundError:
                print("\t{} file not found.\n".format(paths["RC"]),
                      "\tMaking new RC table at: {}\n".format(paths["RC"]))
                actions = ("make", "save")
            try:  # GS
                self[method].GS = IO.from_pickle(paths["GS"], ext="pickle")
            except FileNotFoundError:
                print("\t{} file not found.\n".format(paths["GS"]),
                      "\tMaking new GS table at: {}\n".format(paths["GS"]))
                actions = ("make", "save")

        if "make" in actions:  # Make it
            self[method].RC = self[method].RCf.loc[self.useIDs].copy()
            self[method].GS = self[method].GSf.loc[self.useIDs].copy()
        
            # modern pandas requires keyword argument axis=
            self[method].GS.drop("use",   axis=1, inplace=True)
            self[method].GS.drop("crit",  axis=1, inplace=True)
            self[method].GS.drop("color", axis=1, inplace=True)
            self[method].GS.drop("Lbulge", axis=1, inplace=True)
        
        if "save" in actions:
            IO.save_df(self[method].RC, paths["RC"], save_pickle=save_pickle)
            IO.save_df(self[method].GS, paths["GS"], save_pickle=save_pickle)

    # make_comparison_view
    # -------------------------------------------------------------------------
    def make_comparison_view(self, method, actions="load", paths=None,
                             save_pickle=False):
        """makes a selected view without 'cut' galaxies
        and with fiducial values for all properties except M2L

        Info:
        ---------------
        makes a selected view without cut galaxies
        and with fiducial values for all properties except M2L

        Arguments:
        ---------------
        method: str
            the fit method

        Returns:
        ---------------
        None. all edits made in place
        """
        assert isinstance(method, str)
        assert isinstance(save_pickle, bool)
        # Path Construction
        if paths is None:  # make default paths
            paths = self._make_method_paths(method, RCf=False, RC=False,
                                            GSf=False, GS=False,
                                            total=False, info=False)
        assert isinstance(paths, dict)

        if "load" in actions:
            try:  # RC
                self[method].RCc = IO.from_pickle(paths["RCc"], ext="pickle")
            except FileNotFoundError:
                print("\t{} file not found.\n".format(paths["RCc"]),
                      "\tMaking new RC table at: {}\n".format(paths["RCc"]))
                actions = ("make", "save")

            try:  # GS
                self[method].GSc = IO.from_pickle(paths["GSc"], ext="pickle")
            except FileNotFoundError:
                print("\t{} file not found.\n".format(paths["GSc"]),
                      "\tMaking new GS table at: {}\n".format(paths["GSc"]))
                actions = ("make", "save")

        if "make" in actions:  # if "make" in actions: # Make it
            self[method].RCc = self.fid.RC.copy()
            self[method].GSc = self.fid.GS.copy()

            # RC M2Ls
            self[method].RCc["M2L"] = self[method].RC["M2L"]
            self[method].RCc["e_M2L"] = self[method].RC["e_M2L"]
            self[method].RCc["M2Lb"] = self[method].RC["M2Lb"]
            self[method].RCc["e_M2Lb"] = self[method].RC["e_M2Lb"]

            # GS M2Ls
            self[method].GSc["M2L"] = self[method].GS["M2L"]
            self[method].GSc["e_M2L"] = self[method].GS["e_M2L"]
            self[method].GSc["M2Lb"] = self[method].GS["M2Lb"]
            self[method].GSc["e_M2Lb"] = self[method].GS["e_M2Lb"]

        if "save" in actions:
            IO.save_df(self[method].RCc, paths["RCc"], save_pickle=save_pickle)
            IO.save_df(self[method].GSc, paths["GSc"], save_pickle=save_pickle)
