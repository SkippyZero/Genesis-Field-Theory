#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""weighting functions
"""

##############################################################################
# Importing Modules

import numpy as np
import lmfit as lf

# import os, sys
# sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

# from main import Gal
import Functions.ParamControl as pmc

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Log Probability

def lnprob(p, resid_func, fn_args, fn_kws):
    resid = resid_func(p, *fn_args, **fn_kws)
    resid *= resid
    resid += np.log(2 * np.pi)
    return -0.5 * np.sum(resid)


##############################################################################
# Fit Methods

def residual(p, ID):
    """Basic scaled residual function
    (Vbar[ID](p) - Vobs) / e_Vobs

    Info:
    ---------------
    Basic scaled residual function
    (Vbar[ID](p) - Vobs) / e_Vobs

    Arguments:
    ---------------
    p: lmfit Parameters object
        must be the parameters for bar.Vbar
    ID: str
        galaxy ID

    Returns:
    ---------------
    residual
    """
    return (Gal.galx[ID].Vbar.func(p) - Gal.prlm.RCf.loc[ID]["Vobs"].values) /\
        Gal.prlm.RCf.loc[ID]["e_Vobs"].values


def wgt_residual(p, ID, wgt_func=None, wgt_args=[], wgt_kws={}, **kw):
    """resdiaul weighted by a weighting function
    (Vbar[ID](p) - Vobs) * wgt_func(*wgt_args, **wgt_kws) / e_Vobs + overmax adjustment

    Info:
    ---------------
    Basic scaled residual function
    (Vbar[ID](p) - Vobs) * wgt_func(*wgt_args, **wgt_kws) / e_Vobs

    Arguments:
    ---------------
    p: lmfit Parameters object
        must be the parameters for bar.Vbar
    ID: str
        galaxy ID
    wgt_func: func
        the weighting function
    wgt_args: array-like
        list of arguments for weighting function
    wgt_kws: array-like
        dictionary of kwargs for weighting function

    Key-Word Args:
    ---------------
    wgt_factor: scalar / array
        the overmaximality tuning factor

    Returns:
    ---------------
    weighted residual
    """
    wgt = wgt_func(p, ID, *wgt_args, **wgt_kws)
    resid = residual(p, ID) * wgt
    ind = (resid >= 0.)  # overmaximality

    if True in ind:  # any overmaximality
        try:
            resid[ind] += np.sum(resid[ind] * wgt[ind] *
                                 kw.get("wgt_factor", 1.))
        except:
            resid[ind] += np.sum(resid[ind] * wgt * kw.get("wgt_factor", 1.))
    return resid


def pre_wgt_resid(p, ID, wgt, **kw):
    """resdiaul weighted by a weighting
    (Vbar[ID](p) - Vobs) * wgt / e_Vobs

    Info:
    ---------------
    Basic scaled residual function
    (Vbar[ID](p) - Vobs) * wgt / e_Vobs

    Arguments:
    ---------------
    p: lmfit Parameters object
        must be the parameters for bar.Vbar
    ID: str
        galaxy ID
    wgt: scalar or array-like
        the weight
        if array, must be same length as residual

    Key-Word Args:
    ---------------
    wgt_factor: scalar / array
        the overmaximality tuning factor

    Returns:
    ---------------
    weighted residual
    """
    resid = residual(p, ID) * wgt
    ind = (resid >= 0.)  # overmaximality

    if True in ind:  # any overmaximality
        try:
            resid[ind] += np.sum(resid[ind] * wgt *
                                 kw.get("wgt_factor", 1.))
        except:
            resid[ind] += np.sum(resid[ind] * wgt[ind] *
                                 kw.get("wgt_factor", 1.))
    return resid


##############################################################################
# Weighting

def lognorm_pdf(x, mu, sig):
    """Probability density function for lognormal distribution
        evaluated over an array

        Info:
        ---------------
        Probability density function for lognormal distribution
        evaluated over an array
        https://en.wikipedia.org/wiki/Log-normal_distribution

        Arguments:
        ---------------
        x: 1darray
            the array over which to evaluate the lognorm pdf
        mu: scalar
            the mean of variable's natural logarithm
        sig: scalar
            the standard deviation of variable's natural logarithm

        Returns:
        ---------------
        pdf evaluated over x
    """
    return (np.exp(-np.square(np.log(x) - mu) / (2 * sig**2)) /
            (x * sig * np.sqrt(2 * np.pi)))


def lognorm_weight(p, ID):
    """lognormal weighting over galactocentric radius

        Info:
        ---------------
        lognormal weighting over galactocentric radius
            for the galaxy with the given ID.
        if t(R) < 1e-10: R += 1e-10
        weighting is vertically shifted by .1 so all points are considered

        Parameters:
        ---------------
        p: lmfit parameter object
        unused here

        Arguments:
        ---------------
        ID: str
            galaxy ID

        Returns:
        ---------------
        wgt: scalar / 1darray
    """
    R = Gal.prlm.RCf.loc[ID, "R"].values
    if np.min(R) < 1e-3:
        R += 1e-3
    out = lognorm_pdf(R, np.mean(np.log(R)), np.std(np.log(R)))
    return 10 * out / max(out)


def bulge_lognorm_weight(p, ID):
    """lognormal weighting over galactocentric radius

        Info:
        ---------------
        lognormal weighting over galactocentric radius
            for the galaxy with the given ID.
        if t(R) < 1e-10: R += 1e-10
        weighting is vertically shifted by .1 so all points are considered

        Parameters:
        ---------------
        p: lmfit parameter object
        unused here

        Arguments:
        ---------------
        ID: str
            galaxy ID

        Returns:
        ---------------
        wgt: scalar / 1darray
    """
    out = lognorm_weight(p, ID)
    out[:np.where(out == max(out))[0][0]] = max(out)
    return out

##############################################################################
# Correlation Fit

def list_package(arg):
    if arg is None:
        return [arg,]
    elif (all(isinstance(el, str) for el in arg) or
          all(el is None for el in arg)):
        return [arg,]
    else:
        return list(arg)


def M2Lb_degenerator(ID, params, varyparams, M2Lb_degenerate):
    if M2Lb_degenerate is True:

        if (not isinstance(varyparams, str) and  # list of varyparams 
            ("M2L" in varyparams) and  # M2Lb only degenerate with M2L
            (Gal.prlm.GSf.loc[ID, "Lbulge"] == 0.)):  # No bulge component

            varyparams = np.array(varyparams)  # making sure ndarray
            ind = (varyparams == "M2Lb")
            varyparams = varyparams[~ind]  # select out M2Lb

            params["delta"].value = 0.
            params["M2Lb"].value = 0.  # set M2Lb to 0
            params["M2Lb"].vary = False  # set M2Lb to 0

    return params, varyparams


def do_fit(ID, fullname, aka, seedvaldict={}, varyparams=[],
           minmethods="leastsq",
           wgt=None,
           wgt_func=None, wgt_args=[], wgt_kws={},
           wgt_factor=7.,
           M2Lb_degenerate=False, bulge_wgt_func=None):

    galx = Gal.galx[ID]
    if aka not in galx.methods.value:
        galx.methods.append(aka)
        galx.methods.add(fullname, aka=aka, params=None, mi=None, mcmc=None)

    # seeding parameter values
    params = pmc.set("value", galx.params, seedvaldict, inplace=False)

    if wgt is not None:  # pre-weighted
        residmethod = pre_wgt_resid
        fcn_args = [ID, wgt]
        fcn_kws = {"wgt_factor": wgt_factor}
    else:  # use given weighting func
        # bulge-weighted galaxy
        if bulge_wgt_func is not None and Gal.prlm.GSf.loc[ID, "Lbulge"] > 0:
            wgt_func = bulge_wgt_func
        residmethod = wgt_residual
        fcn_args = [ID]
        fcn_kws = {"wgt_func": wgt_func,
                   "wgt_args": wgt_args,
                   "wgt_kws": wgt_kws,
                   "wgt_factor": wgt_factor}

    mini = lf.Minimizer(residmethod, params,
                        fcn_args=fcn_args,
                        fcn_kws=fcn_kws)

    # making nested array
    varyparams = list_package(varyparams)
    minmethods = list_package(list_package(minmethods))

    # array broadcasting
    if len(varyparams) % len(minmethods) == 0:
        minmethods = minmethods * (len(varyparams) // len(minmethods))
    if len(minmethods) % len(varyparams) == 0:
        varyparams = varyparams * (len(minmethods) // len(varyparams))
    else:
        raise Exception("lists cannot be broadcast to same length")

    # do a fit with no variable parameters to get blank MinimizerResult
    mi = mini.minimize(method="leastsq",
                       params=pmc.set_true(params, []))

    # doing minimization series
    for varyp, minmethod in zip(varyparams, minmethods):
        # Prepping Parameters for fit
        mi.params, varyp = M2Lb_degenerator(ID, mi.params, varyp, M2Lb_degenerate)
        mi.params = pmc.set_true(mi.params, varyp)
        if mi.params['M2Lb'].vary is True:
            mi.params['delta'].vary = True

        # if Gal.prlm.GSf.loc[ID, "Lbulge"] > 0:
        #     print(minmethod, 'bulge', [(p, "{:.2f}".format(mi.params[p].value), mi.params[p].vary) for p in mi.params])
        # else:
        #     print(minmethod, [(p, "{:.2f}".format(mi.params[p].value), mi.params[p].vary) for p in mi.params])

        if not isinstance(minmethod, str):  # series of minimizations
            for method in minmethod:
                mi = mini.minimize(method=method, params=mi.params)
        else:  # one minimization
            mi = mini.minimize(method=minmethod, params=mi.params)

        # print([(p, "{:.2f}".format(mi.params[p].value), mi.params[p].vary) for p in mi.params], '\n')

    # Storing Results
    galx.methods[aka].mi = mi
    galx.methods[aka].params = mi.params

    return mi.params


def do_mcmc(ID, fullname, aka, seedvaldict={}, varyparams=[],
            minmethodss="leastsq",
            wgt=None,
            wgt_func=None, wgt_args=[], wgt_kws={},
            wgt_factor=7.,
            M2Lb_degenerate=False, bulge_wgt_func=None,
            params=None):

    galx = Gal.galx[ID]
    if params is None:
        params = galx.methods[aka].mi.params

    if wgt is not None:
        residmethod = pre_wgt_resid
        fcn_args = [ID, wgt]
        fcn_kws = {"wgt_factor": wgt_factor}
    else:
        if bulge_wgt_func is not None and Gal.prlm.GSf.loc[ID, "Lbulge"] > 0:
            wgt_func = bulge_wgt_func
        residmethod = wgt_residual
        fcn_args = [ID]
        fcn_kws = {"wgt_func": wgt_func,
                   "wgt_args": wgt_args,
                   "wgt_kws": wgt_kws,
                   "wgt_factor": wgt_factor}

    mini = lf.Minimizer(lnprob, params,
                        fcn_args=[residmethod, fcn_args, fcn_kws])

    res = mini.emcee(burn=200, steps=600, thin=10)

    galx.methods[aka].mcmc = res
    galx.methods[aka].params = res.params

    return res.params


def do_fits(fullname, aka, seedvaldict={}, varyparams=[], minmethods="leastsq",
            wgt=None,
            wgt_func=None, wgt_args=[], wgt_kws={},
            wgt_factor=7.,
            M2Lb_degenerate=False,
            bulge_wgt_func=None,
            do_emcee=False):

    actions = Gal.make_method(fullname, aka, actions="load", full_output=True,
                              do_fit_args=(fullname, aka, seedvaldict, varyparams,
                                           minmethods, wgt, wgt_func, wgt_args, wgt_kws,
                                           wgt_factor, M2Lb_degenerate, bulge_wgt_func))

    if "make" in actions:  # wasn't loaded

        for ID in Gal.IDs:
            print(ID, end=", ")

            galx = Gal.galx[ID]
            params = do_fit(ID, *Gal[aka].do_fit_args)

            if do_emcee is True:
                params = do_mcmc(ID, *Gal[aka].do_fit_args, params=params)

            Gal.update_method(aka, ID, galx, params)

        # Adding after updating
        Gal.make_select_view(aka, actions="make")
        Gal.make_comparison_view(aka, actions="make")

        Gal.save_method(fullname)
