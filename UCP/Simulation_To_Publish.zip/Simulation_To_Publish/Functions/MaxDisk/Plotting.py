#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""weighting functions
"""

##############################################################################
# Importing Modules

import numpy as np

from main import Salm, Gal
from Plotting import errorfill


import matplotlib.pyplot as plt
# Plotly
import plotly.plotly as plotly
import plotly.offline as py
import plotly.graph_objs as go
import plotly.tools as tls
py.init_notebook_mode(connected=True)

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code

def plot_weighted_fit(method, suptitle, save, fpath="Output/images/MaxDisk/Vbar/",
                      Rstart=False):
    fig, ax = plt.subplots(nrows=1, ncols=2, figsize=(15, 6))

    for ID in Salm.use:

        galx = Gal.galx[ID]

        # Vobs Pre-Fit
        line, _ = errorfill(Gal.fid.RCf.loc[ID, "R"],
                            Gal.fid.RCf.loc[ID, "Vobs"],
                            yerr=Gal.fid.RCf.loc[ID, "e_Vobs"],
                            ax=ax[0], label=ID)
        color = line.get_color()
        ax[0].errorbar(Gal.fid.RCf.loc[ID, "R"],
                       Gal.fid.RCf.loc[ID, "Vbar"],
                       yerr=Gal.fid.RCf.loc[ID, "e_Vbar"],
                       c=color, ls="--")
        ax[0].axvline(2.2 * galx.params["Rd"].value,
                      label="2.2Rd", c=color, ls="-.", alpha=.3)
        ax[0].axvline(Gal[method].GSf.loc[ID, "Rp"],
                      label="Rp", c=color, ls=":", alpha=.3)
        if Rstart is True:
            ax[0].axvline(galx.params["Rstart"].value,
                          label="Rstart", c=color, ls="--", alpha=.3)


        # Vobs Post-Fit
        errorfill(Gal[method].RCf.loc[ID, "R"], Gal[method].RCf.loc[ID, "Vobs"],
                  yerr=Gal[method].RCf.loc[ID, "e_Vobs"],
                  ax=ax[1], label=ID, color=color)
        # ax[1].errorbar(Gal[method].RCf.loc[ID, "R"], Gal[method].RCf.loc[ID, "Vobs"],
        #                yerr=Gal[method].RCf.loc[ID, "e_Vobs"],
        #                label=ID, color=color)
        ax[1].errorbar(Gal[method].RCf.loc[ID, "R"],
                       Gal[method].RCf.loc[ID, "Vbar"],
                       yerr=Gal[method].RCf.loc[ID, "e_Vbar"],
                       c=line.get_color(), ls="--",)
        ax[1].axvline(2.2 * galx.methods[method].mi.params["Rd"].value,
                      label="2.2Rd", c=color, ls="-.", alpha=.3)
        ax[1].axvline(Gal[method].GSf.loc[ID, "Rp"],
                      label="Rp", c=color, ls=":", alpha=.3)
        if Rstart:
            ax[1].axvline(galx.methods[method].mi.params["Rstart"].value,
                          label="Rstart", c=color, ls="--", alpha=.3)

    # Plot Properties
    fig.suptitle(suptitle, position=(0.5, .975))
    ax[0].set_title("Pre-Fit")
    ax[0].set_xlabel("R [kpc]")
    ax[0].set_ylabel(r"V [$\frac{\mathrm{km}}{\mathrm{s}}$]")
    ax[0].legend(loc="lower right", fontsize=8)

    ax[1].set_title("Post-Fit")
    ax[1].set_xlabel("R [kpc]")
    ax[1].set_ylabel(r"V [$\frac{\mathrm{km}}{\mathrm{s}}$]")
    ax[1].legend(loc="lower right", fontsize=8)

    fig.tight_layout(rect=(0, -.025, 1, .975))
    fig.savefig(fpath + save, format="png", dpi=1000)

    return fig, ax


# ----------------------------------------------------------------------------
# Plot M2L
def plot_M2L(method, suptitle, save, fpath="Output/images/MaxDisk/Vbar/", GStype="GS"):
    errstyle = dict(marker=".", ms=4, c="b", ls="",
                    elinewidth=2, ecolor=(0, 0, 1, .3))

    fig, ax = plt.subplots(2, 3, figsize=(9, 6))

    ax[0, 0].errorbar(Gal[method][GStype]["L[3.6]"], Gal[method][GStype]["M2L"],
                      yerr=Gal[method][GStype]["e_M2L"],
                      xerr=Gal[method][GStype]["e_L[3.6]"],
                      **errstyle)
    ax[0, 1].errorbar(Gal[method][GStype]["SBeff"], Gal[method][GStype]["M2L"],
                      yerr=Gal[method][GStype]["e_M2L"],
                      xerr=Gal[method][GStype]["e_SBeff"],
                      **errstyle)
    ax[0, 2].errorbar(Gal[method][GStype]["T"], Gal[method][GStype]["M2L"],
                      yerr=Gal[method][GStype]["e_M2L"],
                      **errstyle)
    ax[1, 0].errorbar(Gal[method][GStype]["SB0"], Gal[method][GStype]["M2L"],
                      yerr=Gal[method][GStype]["e_M2L"],
                      xerr=Gal[method][GStype]["e_SB0"],
                      **errstyle)
    ax[1, 1].errorbar(Gal[method][GStype]["SBbar"], Gal[method][GStype]["M2L"],
                      yerr=Gal[method][GStype]["e_M2L"],
                      xerr=Gal[method][GStype]["e_SBbar"],
                      **errstyle)
    ax[1, 2].errorbar(Gal[method][GStype]["Mbar"], Gal[method][GStype]["M2L"],
                      yerr=Gal[method][GStype]["e_M2L"],
                      xerr=Gal[method][GStype]["e_Mbar"],
                      **errstyle)

    props = ("L[3.6]", "SBeff", "T", "SB0", "SBbar", "Mbar")
    spots = ((0, 0), (0, 1), (0, 2), (1, 0), (1, 1), (1, 2))
    for spot, prop in zip(spots, props):
        if GStype == "GS":
            prop += " fit"
        elif GStype == "GSc":
            prop += " comp"
        i, j = spot
        try:
            ax[i, j].plot(np.exp(Gal[method][prop].x),
                          np.exp(Gal[method][prop].value),
                          "k--", lw=1,
                          label=Gal[method][prop].coeffs)
        except KeyError:
            print("failed", method, prop)

    # Plot Properties
    fig.suptitle(suptitle, position=(0.5, .975))
    titles = (r"M2L Fit vs Luminosity",
              r"M2L Fit vs $\Sigma_{\mathrm{eff}}$",
              r"M2L Fit vs Hubble Type",
              r"M2L Fit vs $\Sigma_0$",
              r"M2L Fit vs $\Sigma_{\mathrm{bar}}$",
              r"M2L Fit vs $M_{\mathrm{bar}}$")
    xlabels = ("L[3.6]",
               r"$\Sigma_{\mathrm{eff}}$",
               r"Hubble Type",
               r"$\Sigma_0$",
               r"$\Sigma_{\mathrm{bar}}$",
               r"$M_{\mathrm{bar}}$")

    # Plot Properties
    for ind, (i, j) in enumerate(zip([0, 0, 0, 1, 1, 1], [0, 1, 2, 0, 1, 2])):
        ax[i, j].set_title(titles[ind])
        ax[i, j].set_xlabel(xlabels[ind])
        ax[i, j].set_xscale("log")
        ax[i, j].set_yscale("log")
        ax[i, j].set_ylabel("M2L")
        ax[i, j].legend(loc="upper right", fontsize=7)

    fig.tight_layout(rect=(0, -.025, 1, .975))
    fig.savefig(fpath + save + "_M2L",
                format="png", dpi=1000)

# ----------------------------------------------------------------------------
# # Plot Correlation
# def plot_corr(method, suptitle, save, fpath="Output/images/MaxDisk/Vbar/"):
#     fig, ax = plt.subplots(1, 2, figsize=(8, 4))

#     for ID in Gal.useIDs:
#         ax[0].plot(Gal.galx[ID].methods[method].mi.params["Rstart"].value,
#                    Gal.galx[ID].methods[method].mi.params["M2L"].value,
#                    marker=".", ms=4, c="b")
#         ax[1].plot((Gal.galx[ID].methods[method].mi.params["Rstart"].value /
#                     Gal.galx[ID].Rdisk.value),
#                    Gal.galx[ID].methods[method].mi.params["M2L"].value,
#                    marker=".", ms=4, c="b")

#     # Plot Properties
#     fig.suptitle(suptitle, position=(0.5, .975))
#     [ax[i].set_title("M2L vs Rstart Correlation Plot") for i in range(2)]
#     ax[0].set_xlabel("$Rstart$")
#     ax[1].set_xlabel(r"$R_{\mathrm{start}}/R{\mathrm{disk}}$")
#     ax[0].set_xscale("log")
#     [ax[i].set_ylabel("M2L") for i in range(2)]
#     [ax[i].set_yscale("log") for i in range(2)]
#     fig.tight_layout(rect=(0, -.025, 1, .975))
#     fig.savefig(fpath + save + "_corr")


# ----------------------------------------------------------------------------
# Plot Galaxy Property Interactive
def plot_eachgal(fname, method, props, GStype="GS",
                 fpath="Output/images/MaxDisk/Vbar/"):

    data = []
    props = [props] if isinstance(props, str) else props

    for i, prop in enumerate(props):
        y = Gal[method][GStype][prop]

        if "e_" + prop in Gal[method][GStype]:
            dy = Gal[method][GStype]["e_" + prop]
        elif "e_(" + prop + ")" in Gal[method][GStype]:
            dy = Gal[method][GStype]["e_(" + prop + ")"]
        else:
            dy = 0

        if (i == 0) and ("color" in Gal[method][GStype]):
            color = Gal[method][GStype]["color"]
            text = Gal[method][GStype]["crit"]
        elif "color" in Gal[method][GStype]:
            color = "#f49841"
            text = None
        else:
            color = '#447adb'
            text = None

        x = Gal[method][GStype]["ID"].values

        trace = go.Bar(name=prop,
                       x=x,
                       y=y,
                       text=text,
                       marker={"color": color},
                       error_y=dict(type='data',
                                    array=dy,
                                    color="#858585",
                                    opacity=.5,))
        data.append(trace)

    layout = {"title": '{} for {}:{} Data'.format(props, method, GStype),
              'xaxis': {'title': "IDs",
                        'range': [0, len(y)]},
              'yaxis': {'title': prop,
                        'range': [0, np.max(y) + np.max(dy)]},
             'barmode': 'group',
             'autosize': True,
             'width': len(x) * 15,
             'height': 500,
              }
    fig = {'data': data,
           'layout': layout}

    return py.iplot(fig, filename=fname)
