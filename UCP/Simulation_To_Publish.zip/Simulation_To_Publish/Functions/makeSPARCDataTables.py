#!/usr/bin/env python
# -*- coding: utf-8 -*-


##############################################################################
# Importing Modules

import numpy as np
import pandas as pd

import Functions.Baryons.ExpDisk2D as bar

from Functions.Store import Store
import Functions.Convert as cn
import Functions.IO as IO

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Rotation Curve Data

def make_RC(params, full_output=False,
            fpath="Output/Tables/Preliminary RC Table",
            save_pickle=True,
            databasepath="Databases/SPARC/MassModels_Lelli2016c.mrt"):
    """Make Rotation Curve dataframe from SPARC

    Info:
    ---------------
    Make Rotation Curve dataframe from SPARC,
        and RC information Store object

    added RCf fields:
    - M2L
    - e_M2L
    - e_Vdisk
    - e_SBdisk
    - e_Vbul
    - e_SBbul
    - Vbar
    - e_Vbar

    Arguments:
    ---------------
    params: lmfit Parameters object
        the parameters for use in all minimizations
        must include M2L
    full_output: bool
        whether to return RC object and RCf datatable
    fpath: str
        file path for making RC data tables
    save_pickle: bool
        whether to save data table as .pickle file

    Returns:
    ---------------
    RCf: pandas DataFrame
        Rotation Curve dataframe from SPARC
    RC information object if full_output is True
    """

    # Parameters
    p = params.copy()
    p["M2L"].value = 1.  # just making sure

    # Rotation Curve Store object
    RC = Store("Rotation Curves",
               fname=databasepath,
               header=None, hdr_sep=25,
               props=np.array(["ID", "D", "R", "Vobs", "e_Vobs", "Vgas",
                               "Vdisk", "Vbul", "SBdisk", "SBbul"]),
               note="vals at M2L = 1.")

    # Loading Headers
    with open(RC.fname) as infile:  # Rot Curve Data
        RC.header = "".join([infile.readline() for line in range(RC.hdr_sep)])

    # Loading Data
    RCf = pd.read_csv(RC.fname, skiprows=RC.hdr_sep,
                      delim_whitespace=True, header=None,
                      names=tuple(RC.props), engine="python")

    # RCf Multi-Index
    unique, counts = np.unique(RCf["ID"], return_counts=True)
    index = []
    for count in counts:
        index.extend(list(range(count)))
    RCf.set_index([RCf["ID"], index], inplace=True)

    # Adding M2L
    pos = RCf.columns.get_loc("ID")
    RCf.insert(pos + 1, "M2L", 1.)  # after ID
    RCf.insert(pos + 2, "e_M2L", 0.)  # no value yet
    RCf.insert(pos + 3, "M2Lb", 1.)  # after ID
    RCf.insert(pos + 4, "e_M2Lb", 0.)  # no value yet

    # e_Vdisk (no error yet)
    RCf.insert(RCf.columns.get_loc("Vdisk") + 1, "e_Vdisk", 0.)
    # e_SBdisk (no error yet)
    RCf.insert(RCf.columns.get_loc("SBdisk") + 1, "e_SBdisk", 0.)
    # e_Vbul (no error yet)
    RCf.insert(RCf.columns.get_loc("Vbul") + 1, "e_Vbul", 0.)
    # e_SBbul (no error yet)
    RCf.insert(RCf.columns.get_loc("SBbul") + 1, "e_SBbul", 0.)

    # Vbar (no error yet)
    pos = RCf.columns.get_loc("e_Vbul")
    RCf.insert(pos + 1, "Vbar",
               bar.Vbar(p, RCf["Vdisk"], RCf["Vbul"], RCf["Vgas"]))
    RCf.insert(pos + 2, "e_Vbar",
               bar.e_Vbar(p, RCf["Vdisk"], RCf["e_Vdisk"],
                          RCf["Vbul"], RCf["e_Vbul"],
                          RCf["Vgas"]))

    # Saving
    if fpath not in (False, None):
        fpath = "Output/Tables/Preliminary RC Table" if fpath \
                is True else fpath
        IO.save_df(RCf, fpath, save_pickle=save_pickle)
        IO.to_pickle({"RC": RC, "RCf": RCf}, fpath + " & info", ext="pickle")

    # Output
    if full_output is True:
        return RCf, RC
    return RCf


def make_GS(params, full_output=False,
            fpath="Output/Tables/Preliminary GS Table",
            loadRC=False, RCpath=False, returnRC=False,
            save_pickle=False,
            databasepath="Databases/SPARC/Table1wbulge.mrt"):
    """Make Galaxy Sample dataframe from SPARC

    Info:
    ---------------
    Make Galaxy Sample dataframe from SPARC,
        and GS information Store object

    added GSf fields:
    - M2L: mass-to-light ratio
    - e_M2L: mass-to-light ratio uncertainty
    - use: if cut or kept by criteria
    - crit: which (cut) criteria it matched
    - color: corresponding color for visualizations
    - Mbar: baryoninc mass
    - e_Mbar: baryonic mass uncertainty
    - e_SBeff: effective surface brightness
    - e_SB0: effective surface brightness uncertainty
    - pk_ind: index of peak in Vbar
    - Rp: R [kpc] for Vbar peak
    - Vp: observed peak
    - e_Vp: Vbar peak uncertainty
    - Vb: baryon velocity at Rp
    - e_Vb: baryon velocity uncertainty at Rp
    - Vb/Vp: disk maximality
        (Vb / Vp)
    - e_(Vb/Vp): disk maximality uncertainty
        (Vb / Vp error)
    - V2p/Rp: observed peak acceleration
        (Vp^2 / Rp)
    - e_(V2p/Rp):  observed peak acceleration uncertainty
        (Vp^2 / Rp error)
    - V2b/Rp: baryon peak acceleration
        (Vb^2 / Rp)
    - e_(V2b/Rp): baryon peak acceleration uncertainty
        (Vb^2 / Rp error)
    - SBbar: baryonic surface brightness
    - e_SBbar: baryonic surface brightness uncertainty

    Arguments:
    ---------------
    params: lmfit Parameters object
        the parameters for use in all minimizations
        must include M2L
    full_output: bool
        whether to return GS object and GSf datatable
    fpath: str
        file path for making GS data tables
    loadRC: bool, dataframe
        whether to load RC or make a new one
        default: False
        - False -> make a new dataframe
        - DataFrame -> use passed RCf
        - True / None -> RCpath = "Output/Tables/Preliminary RC Table" and load
        - str -> load
    RCpath: bool
        default: False
        gets passed to makeRC as fpath
    returnRC: bool
        whether to return RC or not
    save_pickle: bool
        whether to save data table as .pickle file

    Returns:
    ---------------
    GSf: pandas DataFrame
        Rotation Curve dataframe from SPAGS
    RC information object if full_output is True
    """

    p = params.copy()
    p["M2L"].value = 1.

    GS = Store("Galaxy Sample",
               fname=databasepath,
               header=None, hdr_sep=99,
               props=np.array(["ID", "T", "D", "e_D", "f_D", "inc", "e_inc",
                               "L[3.6]", "e_L[3.6]", "Reff", "SBeff", "Rdisk",
                               "SB0", "MHI", "RHI", "Vflat", "e_Vflat",
                               "Q", "Ref", "Lbulge"]),
               note="vals at M2L = 1.")

    # GS Data
    # --------------------------------------------------------------------
    # Load
    GSf = pd.read_csv(GS.fname, skiprows=GS.hdr_sep,
                      delim_whitespace=True, header=None,
                      names=tuple(GS.props), engine="python")
    # Reorder Cols
    cols = list(GSf.columns.values)  # list of all columns in df
    cols.pop(cols.index('Q'))  # Remove b from list
    cols.pop(cols.index('Ref'))  # Remove b from list
    GSf = GSf[["Ref", "Q"] + cols[0:]]  # reorder cols

    # Set indices
    GSf.set_index(GSf["ID"], drop=False, inplace=True)

    # Add Cut Criteria Information
    # --------------------------------------------------------------------
    pos = GSf.columns.get_loc("Ref")
    GSf.insert(pos + 1, "use", True)
    GSf.insert(pos + 2, "crit", None)
    GSf["crit"] = GSf["crit"].astype(object)  # casting as object
    GSf.insert(pos + 3, "color", "#447adb")

    # Adding Further Properties
    # --------------------------------------------------------------------
    pos = GSf.columns.get_loc("ID")
    GSf.insert(pos + 1, "M2L", 1.)
    GSf.insert(pos + 2, "e_M2L", 0)
    GSf.insert(pos + 3, "M2Lb", 1.)
    GSf.insert(pos + 4, "e_M2Lb", 0)

    # Mbar
    pos = GSf.columns.get_loc("RHI")
    GSf.insert(pos + 1, "Mbar", bar.Mbar(params, GSf["L[3.6]"]))
    GSf.insert(pos + 2, "e_Mbar",
               bar.e_Mbar(params, GSf["L[3.6]"], GSf["e_L[3.6]"]))

    # Correcting Inclination
    # --------------------------------------------------------------------
    # SBeff
    GSf["SBeff"] *= cn.inc_to_faceon(GSf["inc"])
    # e_SBeff
    GSf.insert(GSf.columns.get_loc("SBeff") + 1, "e_SBeff",
               (GSf["SBeff"] *
                cn.e_inc_to_faceon(GSf["inc"], GSf["e_inc"],
                                   dtype="deg")
                ))

    # SB0
    GSf["SB0"] *= cn.inc_to_faceon(GSf["inc"])
    # e_SB0  (only inclination errors, no M2L error yet)
    GSf.insert(GSf.columns.get_loc("SB0") + 1, "e_SB0",
               (GSf["SB0"] *
                cn.e_inc_to_faceon(GSf["inc"], GSf["e_inc"],
                                   dtype="deg")
                ))

    # Adding RC-dependent properties
    # --------------------------------------------------------------------
    if loadRC is False:
        RCf, RC = make_RC(params, fpath=RCpath, full_output=True)
    elif isinstance(loadRC, pd.DataFrame):
        RCf = loadRC
    else:
        RCpath = "Output/Tables/Preliminary RC Table" if loadRC \
                 in (True, None) else loadRC

        d = IO.from_pickle(RCpath, ext="pickle")
        RC, RCf = d["RC"], d["RCf"]

    # initializing columns
    length = len(GSf["ID"])
    pkind = np.zeros(length, dtype=int)
    Rp, Vp, e_Vp, Vb, e_Vb = np.zeros((5, length))

    for i, ID in enumerate(GSf["ID"]):

        # peak index (pk_ind)
        pk_ind = int(np.where(RCf.loc[ID, "Vbar"] ==
                              max(RCf.loc[ID, "Vbar"]))[0][0])
        pkind[i] = pk_ind

        # peak radius (Rp)
        Rp[i] = RCf.loc[(ID, pk_ind), "R"]

        # observed rotation curve peak (Vp)
        Vp[i] = RCf.loc[(ID, pk_ind), "Vobs"]
        e_Vp[i] = RCf.loc[(ID, pk_ind), "e_Vobs"]

        # # observed - gas rotation curve peak (Vp_g)
        # Vp_g[i] = RCf.loc[(ID, pk_ind), "Vobs_g"]
        # e_Vp_g[i] = RCf.loc[(ID, pk_ind), "e_Vobs_g"]

        # baryon rotation curve peak (Vb)
        Vb[i] = RCf.loc[(ID, pk_ind), "Vbar"]
        e_Vb[i] = RCf.loc[(ID, pk_ind), "e_Vbar"]

    # Putting in Pandas DataFrame
    GSf.insert(GSf.columns.get_loc("ID"), "pk_ind", pkind)
    GSf.insert(GSf.columns.get_loc("Reff") + 1, "Rp", Rp)

    pos = GSf.columns.get_loc("e_Vflat")
    # Vp
    GSf.insert(pos + 1, "Vp", Vp)
    GSf.insert(pos + 2, "e_Vp", e_Vp)

    # Vb
    GSf.insert(pos + 3, "Vb", Vb)
    GSf.insert(pos + 4, "e_Vb", e_Vb)

    # Vb/Vp
    GSf.insert(pos + 5, "Vb/Vp", Vb / Vp)
    e_Vb_Vp = np.sqrt((e_Vb / Vp)**2 + (Vb * e_Vp / Vp**2)**2)
    GSf.insert(pos + 6, "e_(Vb/Vp)", e_Vb_Vp)

    # V2p/Rp
    GSf.insert(pos + 7, "V2p/Rp", Vp**2 / Rp)
    e_V2p_Rp = np.sqrt((2 * Vp * e_Vp / Rp)**2)
    GSf.insert(pos + 8, "e_(V2p/Rp)", e_V2p_Rp)

    # V2b/Rp
    GSf.insert(pos + 9, "V2b/Rp", Vb**2 / Rp)
    e_V2b_Rp = np.sqrt((2 * Vb * e_Vb / Rp)**2)
    GSf.insert(pos + 10, "e_(V2b/Rp)", e_V2b_Rp)

    # SBbar (needs to be after Rp)
    pos = GSf.columns.get_loc("e_Mbar")
    GSf.insert(pos + 1, "SBbar",
               bar.SBbar(p, GSf["Rp"], GSf["L[3.6]"]))
    GSf.insert(pos + 2, "e_SBbar",
               bar.SBbar(p, GSf["Rp"], GSf["L[3.6]"], GSf["e_L[3.6]"]))

    # Saving / Returning
    # --------------------------------------------------------------------
    if fpath not in (False, None):
        fpath = "Output/Tables/Preliminary GS Table" if fpath \
                is True else fpath
        IO.save_df(GSf, fpath, save_pickle=save_pickle)
        IO.to_pickle({"GS": GS, "GSf": GSf}, fpath + " & info", ext="pickle")

    if full_output is True:
        if returnRC is True:
            return GSf, GS, RCf, RC
        return GSf, GS
    return GSf


def make_prlm_DataTables(params, full_output=False,
                         RCpath=True, GSpath=True,
                         save_pickle=False,
                         RCdatabasepath="Databases/SPARC/MassModels_Lelli2016c.mrt",
                         GSdatabasepath="Databases/SPARC/Table1wbulge.mrt"):

    if full_output is False:
        RCf = make_RC(params, full_output=False, fpath=RCpath,
                      save_pickle=save_pickle,
                      databasepath=RCdatabasepath)
        GSf = make_GS(params, loadRC=RCf, full_output=False, fpath=GSpath,
                      save_pickle=save_pickle,
                      databasepath=GSdatabasepath)

        return RCf, GSf

    else:
        RCf, RC = make_RC(params, full_output=True, fpath=RCpath,
                          save_pickle=save_pickle,
                          databasepath=RCdatabasepath)
        GSf, GS = make_GS(params, loadRC=RCf, full_output=True, fpath=GSpath,
                          save_pickle=save_pickle,
                          databasepath=GSdatabasepath)

        return RCf, RC, GSf, GS
