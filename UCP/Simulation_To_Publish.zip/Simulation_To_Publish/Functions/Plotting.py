#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""Plotting
"""

##############################################################################
# Importing Modules

import numpy as np
import matplotlib as plt

# My Modules
# from Functions.Initialization import Salm

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
__credits__ = ["Stacy McGaugh, Frederico Lelli"]
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"

##############################################################################
# Begin Code


def errorfill(x, y, yerr=None, ax=None, e_alpha=0.3, e_kws={}, **kw):
    """Errorbar plot but filled errors
        # tonysyu.github.io/plotting-error-bars.html#.WRsuYsaZNcw

        Info:
        ---------------
        Errorbar plot but filled errors
        

        Arguments:
        ---------------
        x: array
            x values
        y: array
            y values
        yerr: array
            y error array
            * default: None
        ax: axes object
            the axes
            * default: None
            if None will creat axes
        e_alpha: scalar
            error alpha value
            between 0 and 1
        e_kws: dict
            dictionary for errors fill area (ax.fill_between)
        
        Key-Word Arguments:
        -------------------
        arguments for ax.plot(x, y, **kw)

        Returns:
        ---------------
        line, fillbetween, (ax implicitly modified)
        """
    ax = ax if ax is not None else plt.gca()
    line, = ax.plot(x, y, **kw)

    if yerr is not None:
        if np.isscalar(yerr) or len(yerr) == len(y):
            ymin = y - yerr
            ymax = y + yerr
        elif len(yerr) == 2:
            ymin, ymax = yerr

        fillbetween = ax.fill_between(x, ymax, ymin, color=line.get_color(),
                                      alpha=e_alpha, **e_kws)
    else:
        fillbetween = None

    return line, fillbetween


def make_ticklabels_invisible(fig):
    """makes ticklabels invisible for all axes in a figure
    """
    for i, ax in enumerate(fig.axes):
        ax.text(0.5, 0.5, "ax%d" % (i+1), va="center", ha="center")
        for tl in ax.get_xticklabels() + ax.get_yticklabels():
            tl.set_visible(False)


def make_xticklabel_invisible(axs):
    """makes xticklabels invisible for given axes
    """
    for i, ax in enumerate(axs):
        for tl in ax.get_xticklabels():
            tl.set_visible(False)
