#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Docstring
"""The 2D Baryonic Exponential Disk
"""

##############################################################################
# Importing Modules
import numpy as np
import scipy.special as spc

# My Modules
import Functions.Convert as cn
# from Functions.Initialization import Gal

##############################################################################
# File Data
__author__ = "Nathaniel Starkman"
# __copyright__ = "Copyright 2007, The Cogent Project"
__credits__ = "Stacy McGaugh", "Frederico Lelli"
__license__ = "GPL"
__version__ = "1.0.1"
__maintainer__ = "Nathaniel Starkman"
__status__ = "Development"


##############################################################################
# Begin Code

def SB(p, R):
    """Baryonic exponential disk mass density
        Book: Binney & Tremaine p.100

        Info:
        ---------------
        designed for lmfit

        Parameters:
        ---------------
        p: lmfit parameter object
        - sig0 : rho(R = 0, z=0)
            - [L⊙ / pc^2]
            * uses cn.perpcn_perkpcn(,2) to convert to [L⊙ / kpc^2]
        - Rd   : Disk Scale Length at [3.6]
            - [kpc]

        Arguments:
        ---------------
        R: scalar / array
            Galactocentric radius [kpc]

        Returns:
        ---------------
        SB: scalar / array
    """
    return p["sig0"].value * np.exp(-R / p["Rd"].value)


def rho(p, R):
    """Baryonic exponential disk mass density
        Book: Binney & Tremaine p.100

        Info:
        ---------------
        designed for lmfit

        Parameters:
        ---------------
        p: lmfit parameter object
        - sig0 : rho(R = 0)
            - [L⊙ / pc^2]
            * uses cn.perpcn_perkpcn(,2) to convert to [L⊙ / kpc^2]
        - Rd: Disk Scale Length at [3.6]
            - [kpc]

        Arguments:
        ---------------
        R: scalar / array
            Galactocentric radius [kpc]

        Returns:
        ---------------
        rho: scalar / array
    """
    return p["sig0"].value * p["M2L"].value *\
        np.exp(-R / p["Rd"].value)


def M(p, R):
    """Baryonic exponential disk mass as function of radius
        Book: B&T 100

        Info:
        ---------------
        designed for lmfit

        Parameters:
        ---------------
        p: lmfit parameter object
        - M2L : mass-to-light ratio
            - [M⊙ / L⊙]
        - sig0 : SB(R = 0)
            - [L⊙ / pc^2]
            * uses cn.perpcn_perkpcn(,2) to convert to [L⊙ / kpc^2]
        - Rd   : Disk Scale Length at [3.6]
            - [kpc]

        Arguments:
        ---------------
        R: scalar / array
            Galactocentric radius [kpc]

        Returns:
        ---------------
        Mass: scalar / array
    """
    v = p.valuesdict()
    return 2 * np.pi * cn.kpc_to_pc(v["Rd"])**2 *\
        v["M2L"] * v["sig0"] *\
        (1 - np.exp(-R / v["Rd"]) * (1 + (R / v["Rd"])))


def Mbar(p, L3_6, adj_units=True):
    """Baryonic Mass

        Info:
        ---------------
        designed for lmfit

        Parameters:
        ---------------
        p: lmfit parameter object
        - M2L : mass-to-light ratio
            - [M⊙ / L⊙]

        Arguments:
        ---------------
        L3_6: scalar / array
            luminosity at 3.6 band
            - [M⊙ / L⊙]
            but SPARC cites in [GM⊙ / L⊙]
        adj_units: bool
            adjusts [GM⊙ / L⊙] to [M⊙ / L⊙]
            DEFAULT: True

        Returns:
        ---------------
        Mbar: scalar / array
            the baryonic mass
    """
    if adj_units is True:
        return L3_6 * 1e9 * p["M2L"].value
    return L3_6 * p["M2L"].value


def e_Mbar(p, L3_6, e_L3_6, adj_units=True):
    """Error in Baryonic Mass

        Info:
        ---------------
        designed for lmfit
        relevant quantities should be at M2L = 1

        Parameters:
        ---------------
        p: lmfit parameter object
        - M2L : mass-to-light ratio
            - [M⊙ / L⊙]

        Arguments:
        ---------------
        L3_6: scalar / array
            luminosity at 3.6 band
            - [M⊙ / L⊙]
            but SPARC cites in [GM⊙ / L⊙]
        e_L3_6: scalar / array
            error in luminosity at 3.6 band
            - [M⊙ / L⊙]
            but SPARC cites in [GM⊙ / L⊙]
        adj_units: bool
            adjusts [GM⊙ / L⊙] to [M⊙ / L⊙]
            DEFAULT: True

        Returns:
        ---------------
        e_Mbar: scalar / array
            error in Mbar()
    """
    e_M2L = float(p["M2L"].stderr) if p["M2L"].stderr is not None else 0.

    if adj_units is True:
        return np.sqrt((L3_6 * 1e9 * e_M2L)**2 +
                       (e_L3_6 * 1e9 * p["M2L"].value)**2)
    return np.sqrt((L3_6 * e_M2L)**2 + (e_L3_6 * p["M2L"].value)**2)


def SBbar(p, Rp, L3_6, adj_units=True):
    """Baryonic Surface Brightness
        0509305.pdf eq. 3

        Info:
        ---------------
        designed for lmfit
        0509305.pdf eq. 3

        Parameters:
        ---------------
        p: lmfit parameter object
        - M2L : mass-to-light ratio
            - [M⊙ / L⊙]

        Arguments:
        ---------------
        Rp: scalar
            R for peak in Vbar
            -[kpc]
        L3_6: scalar / array
            luminosity at 3.6 band
            - [M⊙ / L⊙]
            but SPARC cites in [GM⊙ / L⊙]
        adj_units: bool
            adjusts [GM⊙ / L⊙] to [M⊙ / L⊙]
            DEFAULT: True

        Returns:
        ---------------
        SBbar: scalar / array
            the baryonic surface brightness
    """
    Mb = Mbar(p, L3_6, adj_units)
    return .75 * Mb / np.square(cn.kpc_to_pc(Rp))


def e_SBbar(p, Rp, L3_6, e_L3_6, adj_units=True):
    """Baryonic Surface Brightness Error
        0509305.pdf eq. 3

        Info:
        ---------------
        designed for lmfit
        0509305.pdf eq. 3

        Parameters:
        ---------------
        p: lmfit parameter object
        - M2L : mass-to-light ratio
            - [M⊙ / L⊙]

        Arguments:
        ---------------
        Rp: scalar
            R for peak in Vbar
            -[kpc]
        L3_6: scalar / array
            luminosity at 3.6 band
            - [M⊙ / L⊙]
            but SPARC cites in [GM⊙ / L⊙]
        e_L3_6: scalar / array
            luminosity error at 3.6 band
            - [M⊙ / L⊙]
            but SPARC cites in [GM⊙ / L⊙]
        adj_units: bool
            adjusts [GM⊙ / L⊙] to [M⊙ / L⊙]
            DEFAULT: True

        Returns:
        ---------------
        e_SBbar: scalar / array
            the baryonic surface brightness error
    """

    e_Mb = e_Mbar(p, L3_6, e_L3_6, adj_units)
    return .75 * e_Mb / np.square(cn.kpc_to_pc(Rp))


def Vrot(p, R):
    """Baryonic exponential disk circular rotational velocity
        Book: Binney & Tremaine p.100

        Info:
        ---------------
        designed for lmfit

        Parameters:
        ---------------
        p: lmfit parameter object
        - sig0 : rho(R = 0)
            - [L⊙ / pc^2]
            * uses cn.perpcn_perkpcn(,2) to convert to [L⊙ / kpc^2]
        - Rd   : Disk Scale Length at [3.6]
            - [kpc]
        - G    : Gravitational constant
            - 4.302 [kpc km^2 / M⊙ s^2]

        Arguments:
        ---------------
        R: scalar / array
            Galactocentric radius
            - kpc]

        Returns:
        ---------------
        Vrot: scalar / array
            - [km / s]
    """
    v = p.valuesdict()

    y = R / (2 * v["Rd"])
    return np.sqrt(4 * np.pi * v["G"] * v["Rd"] * v["M2L"] *
                   cn.perpcn_to_perkpcn(v["sig0"], 2) *
                   y**2 * (spc.i0(y) * spc.k0(y) - spc.i1(y) * spc.k1(y)))


def Vbar(p, Vdisk, Vbul, Vgas):
    """Baryonic velocity
        sum of disk and bulge velocity

        Info:
        ---------------
        designed for lmfit
        160505971v2.pdf

        relevant quantities should be at M2L = 1

        Parameters:
        ---------------
        p: lmfit parameter object
        - M2L : mass-to-light ratio
            - [M⊙ / L⊙]

        Arguments:
        ---------------
        Vdisk: scalar / array
            disk velocity
            - [km / s]
        Vbul: scalar / array
            bulge velocity
            - [km / s]
\
        Returns:
        ---------------
        Vbar: scalar / array
            - [km / s]
    """
    out = p["M2L"].value * Vdisk**2 * np.sign(Vdisk)
    out += p["M2Lb"].value * Vbul**2 * np.sign(Vbul)
    out += Vgas**2 * np.sign(Vgas)

    return np.nan_to_num(np.sqrt(out))


def e_Vbar(p, Vdisk, e_Vdisk, Vbul, e_Vbul, Vgas):
    """Baryonic velocity error

        Info:
        ---------------
        designed for lmfit
        160505971v2.pdf

        relevant quantities should be at M2L = 1

        Parameters:
        ---------------
        p: lmfit parameter object
        - M2L : mass-to-light ratio
            - [M⊙ / L⊙]

        Arguments:
        ---------------
        Vdisk: scalar / array
            disk velocity
            - [km / s]
        e_Vdisk: scalar / array
            disk velocity error
            - [km / s]
        Vbul: scalar / array
            bulge velocity
            - [km / s]
        Vbul: scalar / array
            bulge velocity error
            - [km / s]

        Returns:
        ---------------
        e_Vbar: scalar / array
            error in Vbar
            - [km / s]
    """
    e_M2L = float(p["M2L"].stderr) if p["M2L"].stderr is not None else 0.
    e_M2Lb = float(p["M2Lb"].stderr) if p["M2Lb"].stderr is not None else 0.

    # disk M2L error  
    out = (e_M2L * Vdisk**2 / (2 * Vbar(p, Vdisk, Vbul, Vgas)))**2
    # bulge M2L error
    out += (e_M2Lb * Vdisk**2 / (2 * Vbar(p, Vdisk, Vbul, Vgas)))**2
    # Vdisk error
    out += (p["M2L"].value * 2 * Vdisk * e_Vdisk /
            (2 * Vbar(p, Vdisk, Vbul, Vgas)))**2
    # Vbulge error
    out += (p["M2Lb"].value * 2 * Vbul * e_Vbul /
            (2 * Vbar(p, Vdisk, Vbul, Vgas)))**2

    return np.nan_to_num(np.sqrt(out))


def g(p, R, Vrot=Vrot, isfunc=True):
    """Baryonic exponential disk radial acceleration

        Info:
        ---------------
        designed for lmfit

        Parameters:
        ---------------
        p: lmfit parameter object
        - sig0: rho(R = 0)
            - [L⊙ / pc^2]
            * uses cn.perpcn_perkpcn(,2) to convert to [L⊙ / kpc^2]
        - Rd: Disk Scale Length at [3.6]
            - [kpc]
        - G: Gravitational constant
            - 4.302 [kpc km^2 / s^2 M⊙]

        Arguments:
        ---------------
        R: scalar / array
            Galactocentric radius
            - [kpc]
        Vrot: func, scalar / array
            Rotational Velocity
            - [km / s]
            * defaults to ExpDisk2D.Vrot
        isfunc: Bool
            is Vrot a function
            * defaults to True
            TODO? replace with callable(Vrot)

        Returns:
        ---------------
        g: scalar / array
            - [km / s^2]
    """
    if isfunc:  # is True
        return Vrot(p, R)**2 / cn.kpc_to_km(R)
    return Vrot**2 / cn.kpc_to_km(R)
